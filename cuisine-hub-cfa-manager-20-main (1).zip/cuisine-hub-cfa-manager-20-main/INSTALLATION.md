
# Guide d'Installation - Cuisine Hub

## 📋 Pré-requis Système

### Configuration Minimale
- **OS**: Windows 10/11 64-bit, macOS 10.15+, Ubuntu 18.04+
- **RAM**: 4 GB minimum (8 GB recommandé)
- **Stockage**: 2 GB d'espace libre
- **Processeur**: Intel Core i3 ou équivalent AMD

### Configuration Recommandée
- **OS**: Windows 11 64-bit, macOS 12+, Ubuntu 20.04+
- **RAM**: 8 GB ou plus
- **Stockage**: 5 GB d'espace libre (SSD recommandé)
- **Processeur**: Intel Core i5 ou équivalent AMD
- **Réseau**: Connexion Internet pour synchronisation cloud

## 🚀 Installation

### Option 1: Installation via Exécutable (Recommandée)

1. **Télécharger l'application**
   ```
   Téléchargez CuisineHub-Setup.exe depuis le site officiel
   ```

2. **Exécuter l'installateur**
   - Double-cliquez sur `CuisineHub-Setup.exe`
   - Suivez les instructions de l'assistant d'installation
   - Choisissez le répertoire d'installation (par défaut: `C:\Program Files\CuisineHub`)

3. **Première exécution**
   - Lancez l'application depuis le menu Démarrer ou le raccourci bureau
   - Suivez l'assistant de configuration initiale

### Option 2: Installation Développeur

1. **Pré-requis développeur**
   ```bash
   # Node.js 18+ requis
   node --version  # v18.0.0+
   npm --version   # 8.0.0+
   ```

2. **Cloner le projet**
   ```bash
   git clone https://github.com/votre-repo/cuisine-hub.git
   cd cuisine-hub
   ```

3. **Installer les dépendances**
   ```bash
   npm install
   ```

4. **Configuration environnement**
   ```bash
   # Créer le fichier .env.local
   cp .env.example .env.local
   
   # Éditer les variables d'environnement si nécessaire
   nano .env.local
   ```

5. **Démarrer l'application**
   ```bash
   # Mode développement
   npm run dev
   
   # Ou construire pour production
   npm run build
   npm run start
   ```

## ⚙️ Configuration Initiale

### 1. Création du Compte Administrateur

Au premier lancement, vous serez guidé pour créer le compte administrateur :

- **Informations personnelles**: Prénom, nom, email
- **Identifiants de connexion**: Nom d'utilisateur et mot de passe sécurisé
- **Vérification**: Confirmation des informations

### 2. Configuration de la Boutique

Après création du compte admin, configurez votre boutique :

```
Paramètres > Général > Informations de la boutique
- Nom de la boutique
- Adresse et contact
- Devise (XAF, EUR, USD)
- Taux de TVA
```

### 3. Configuration Réseau (Optionnel)

Pour l'accès mobile via hotspot :
```
Paramètres > Connect Mobile
- Configurer le nom du réseau WiFi
- Définir un mot de passe sécurisé
- Noter l'adresse IP d'accès
```

## 🔧 Configuration Avancée

### Base de Données WAMP (Optionnel)
```
Paramètres > Synchronisation > WAMP
- Serveur: localhost ou IP du serveur
- Port: 3306 (MySQL par défaut)
- Base de données: cuisine_hub_db
- Utilisateur: root
- Mot de passe: [votre mot de passe]
```

### Synchronisation Google Drive (Optionnel)
```
Paramètres > Synchronisation > Google Drive
- Connecter votre compte Google
- Choisir le dossier de sauvegarde
- Configurer la fréquence de synchronisation
```

## 🛡️ Sécurité et Sauvegarde

### Sauvegarde Automatique
L'application sauvegarde automatiquement vos données dans :
- **Windows**: `%APPDATA%\CuisineHub\data`
- **macOS**: `~/Library/Application Support/CuisineHub/data`
- **Linux**: `~/.config/CuisineHub/data`

### Sauvegarde Manuelle
```bash
# Exporter toutes les données
Paramètres > Sauvegarder > Exporter tout

# Sauvegarder vers Google Drive
Paramètres > Synchronisation > Synchroniser maintenant
```

### Restauration
```bash
# Importer des données sauvegardées
Paramètres > Restaurer > Importer fichier

# Restaurer depuis Google Drive
Paramètres > Synchronisation > Restaurer depuis Drive
```

## 📱 Accès Mobile

### Configuration Hotspot
1. **Activer le hotspot Windows**
   ```
   Paramètres > Connect Mobile > Démarrer Hotspot
   ```

2. **Connexion des appareils**
   - Connectez votre mobile au réseau WiFi créé
   - Scannez le QR Code affiché ou saisissez l'URL manuellement
   - Accédez à l'application via le navigateur mobile

### URL d'Accès
```
http://192.168.137.1:8080
```

## 🔍 Dépannage

### Problèmes Courants

**Application ne démarre pas**
```bash
# Vérifier les permissions
# Windows: Exécuter en tant qu'administrateur
# macOS/Linux: chmod +x cuisine-hub
```

**Erreur de connexion base de données**
```bash
# Vérifier le service MySQL/WAMP
# Windows: services.msc > MySQL
# Tester la connexion: telnet localhost 3306
```

**Hotspot ne fonctionne pas**
```bash
# Windows: Vérifier les pilotes WiFi
# Exécuter en tant qu'administrateur
netsh wlan show drivers
```

### Logs de Débogage
```
# Emplacement des logs
Windows: %APPDATA%\CuisineHub\logs
macOS: ~/Library/Logs/CuisineHub
Linux: ~/.config/CuisineHub/logs
```

## 📞 Support

### Documentation
- Guide utilisateur complet: `docs/user-guide.pdf`
- API Documentation: `docs/api.md`
- FAQ: `docs/faq.md`

### Contact Support
- Email: support@cuisinehub.com
- Forum: https://forum.cuisinehub.com
- GitHub Issues: https://github.com/votre-repo/cuisine-hub/issues

## 🔄 Mises à Jour

### Mise à jour automatique
L'application vérifie automatiquement les mises à jour au démarrage.

### Mise à jour manuelle
```
Paramètres > Système > Vérifier les mises à jour
```

### Notes de version
Consultez `CHANGELOG.md` pour les détails des nouvelles versions.

---

**Version**: 1.0.0  
**Dernière mise à jour**: Décembre 2024  
**Compatibilité**: Windows 10+, macOS 10.15+, Ubuntu 18.04+
