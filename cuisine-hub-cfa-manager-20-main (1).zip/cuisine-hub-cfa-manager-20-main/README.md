
# 🍽️ Cuisine Hub - Système de Gestion de Magasin

**Version 1.0.0** | **Application de Gestion Complète pour Magasins d'Articles de Cuisine**

![Cuisine Hub Banner](./docs/images/banner.png)

## 📖 Description

Cuisine Hub est une application complète de gestion de magasin d'articles de cuisine développée avec les technologies web modernes. Elle offre une interface intuitive pour gérer les ventes, le stock, les finances et bien plus encore, avec un accès multi-plateforme (desktop et mobile).

## ✨ Fonctionnalités Principales

### 🎯 Gestion des Ventes
- **Point de vente intuitif** avec calcul automatique
- **Gestion des clients** et historique d'achat
- **Méthodes de paiement multiples** (espèces, crédit)
- **Génération de reçus** automatique

### 📦 Gestion du Stock
- **Inventaire en temps réel** avec alertes de stock faible
- **Gestion des fournisseurs** et historique des livraisons
- **Catégorisation avancée** des produits
- **Traçabilité complète** des mouvements de stock

### ⛽ Gestion du Gaz
- **Module spécialisé** pour bouteilles de gaz
- **Suivi des livraisons** et rotations
- **Gestion des consignes** et retours
- **Tarification flexible** par type et taille

### 💰 Gestion Financière
- **Suivi des créances** clients et fournisseurs
- **Tableaux de bord financiers** en temps réel
- **Rapports détaillés** de rentabilité
- **Gestion des dépenses** et marges

### 👥 Gestion Utilisateurs (Admin)
- **Système de rôles avancé** (Admin, Gestionnaire, Vendeur, Observateur)
- **Permissions granulaires** par module
- **Audit trail complet** des actions utilisateurs
- **Gestion des sessions** et sécurité renforcée

### 📊 Rapports et Analytics
- **Tableaux de bord interactifs** avec graphiques
- **Rapports personnalisables** par période
- **Analyses de tendances** et prévisions
- **Export multi-formats** (PDF, Excel, CSV)

### 🔧 Fonctionnalités Techniques

#### 🎨 Interface Utilisateur
- **Design responsive** adaptatif mobile/desktop
- **Thèmes personnalisables** avec variantes bleues
- **Mode sombre/clair** automatique
- **Interface multilingue** (français par défaut)

#### 🔄 Synchronisation
- **WAMP/MySQL** pour serveur local
- **Google Drive** pour sauvegarde cloud
- **Synchronisation bidirectionnelle** intelligente
- **Mode hors-ligne** avec synchronisation différée

#### 📱 Accès Mobile
- **Hotspot WiFi intégré** pour connexion directe
- **Interface mobile optimisée** 
- **QR Code** pour connexion rapide
- **Mode offline** pour ventes sans réseau

#### 🛡️ Sécurité
- **Authentification sécurisée** avec hachage bcrypt
- **Gestion de sessions** avec expiration
- **Audit trail** complet des actions
- **Sauvegarde automatique** chiffrée

## 🏗️ Architecture Technique

### Frontend
- **React 18** + **TypeScript** pour l'interface utilisateur
- **Tailwind CSS** pour le design responsive
- **Shadcn/UI** pour les composants modernes
- **Lucide React** pour les icônes
- **React Query** pour la gestion d'état

### Backend & Storage
- **LocalStorage** pour persistance locale
- **MySQL/WAMP** pour synchronisation serveur
- **Google Drive API** pour sauvegarde cloud
- **QRCode.js** pour génération QR codes

### Build & Packaging
- **Vite** pour le bundling rapide
- **Electron** pour l'application desktop
- **Node.js** pour les scripts système
- **GitHub Actions** pour CI/CD

## 🚀 Installation Rapide

### Option 1: Exécutable (Utilisateur Final)
```bash
# Télécharger CuisineHub-Setup.exe
# Double-cliquer et suivre l'assistant
# Lancer l'application et configurer le compte admin
```

### Option 2: Développement
```bash
# Cloner le projet
git clone https://github.com/votre-repo/cuisine-hub.git
cd cuisine-hub

# Installer les dépendances
npm install

# Démarrer en mode développement
npm run dev
```

Voir le [Guide d'Installation Complet](./INSTALLATION.md) pour plus de détails.

## 📱 Configuration Première Utilisation

1. **Création du compte administrateur**
   - Informations personnelles et identifiants
   - Configuration automatique des permissions

2. **Paramétrage de la boutique**
   - Nom, adresse, contact
   - Devise et taux de TVA
   - Logo personnalisé

3. **Configuration réseau (optionnel)**
   - Hotspot WiFi pour accès mobile
   - Synchronisation cloud

## 🎯 Roadmap

### Version 1.1 (Q1 2025)
- [ ] **Système de fidélité client** avec points
- [ ] **Gestion des promotions** et réductions
- [ ] **Notifications push** pour alertes
- [ ] **API REST** pour intégrations tierces

### Version 1.2 (Q2 2025)
- [ ] **Module de commandes** clients
- [ ] **Gestion multi-magasins**
- [ ] **Intégration comptable** (Sage, QuickBooks)
- [ ] **Tableau de bord exécutif** avancé

### Version 2.0 (Q4 2025)
- [ ] **Intelligence artificielle** pour prévisions
- [ ] **Marketplace** intégrée
- [ ] **Solution SaaS** complète
- [ ] **Application mobile native**

## 🤝 Contribution

Nous accueillons les contributions ! Voir [CONTRIBUTING.md](./CONTRIBUTING.md) pour les guidelines.

### Développement Local
```bash
# Fork du projet
git fork https://github.com/votre-repo/cuisine-hub.git

# Créer une branche feature
git checkout -b feature/nouvelle-fonctionnalite

# Développer et tester
npm run test
npm run lint

# Commit et push
git commit -m "feat: nouvelle fonctionnalité"
git push origin feature/nouvelle-fonctionnalite

# Créer une Pull Request
```

## 📄 Licence

Ce projet est sous licence **MIT**. Voir [LICENSE](./LICENSE) pour plus de détails.

## 📞 Support

### 🌟 Support Premium
- **Email**: support@cuisinehub.com
- **WhatsApp**: +237 6XX XXX XXX
- **Télégraphe**: @CuisineHubSupport

### 🏘️ Communauté
- **Discord**: [Serveur Communauté](https://discord.gg/cuisinehub)
- **Forum**: [forum.cuisinehub.com](https://forum.cuisinehub.com)
- **Documentation**: [docs.cuisinehub.com](https://docs.cuisinehub.com)

### 🐛 Rapporter un Bug
[Créer une issue](https://github.com/votre-repo/cuisine-hub/issues/new?template=bug_report.md)

## 📊 Statistiques du Projet

![GitHub stars](https://img.shields.io/github/stars/votre-repo/cuisine-hub?style=social)
![GitHub forks](https://img.shields.io/github/forks/votre-repo/cuisine-hub?style=social)
![GitHub issues](https://img.shields.io/github/issues/votre-repo/cuisine-hub)
![GitHub license](https://img.shields.io/github/license/votre-repo/cuisine-hub)

**Lignes de code**: ~15,000  
**Composants**: 25+  
**Tests**: 150+  
**Documentation**: 95%

## 🙏 Remerciements

- **Équipe de développement** pour leur travail exceptionnel
- **Communauté beta-testeurs** pour leurs retours précieux
- **Partenaires locaux** pour leur soutien continu

---

**Développé avec ❤️ par l'équipe Cuisine Hub**  
**© 2024 Cuisine Hub. Tous droits réservés.**

*Pour plus d'informations, visitez [cuisinehub.com](https://cuisinehub.com)*
