
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [theme, setTheme] = useState<string>("light");
  const [blueTheme, setBlueTheme] = useState<string>("");
  
  useEffect(() => {
    const storedTheme = localStorage.getItem('app-theme');
    const storedBlueTheme = localStorage.getItem('blue-theme');
    
    // Apply theme
    if (storedTheme) {
      setTheme(storedTheme);
      document.documentElement.classList.toggle('dark', storedTheme === 'dark');
    }
    
    // Apply blue theme if selected
    if (storedBlueTheme) {
      setBlueTheme(storedBlueTheme);
      
      // Remove any existing blue theme classes
      document.documentElement.classList.remove(
        'theme-blue-classic', 
        'theme-blue-night',
        'theme-blue-ocean',
        'theme-blue-corporate'
      );
      
      // Add the selected blue theme
      if (storedBlueTheme) {
        const themeClass = `theme-${storedBlueTheme.toLowerCase().replace(' ', '-')}`;
        document.documentElement.classList.add(themeClass);
      }
    }
    
    // Listen for theme changes
    const handleStorageChange = () => {
      const newTheme = localStorage.getItem('app-theme');
      const newBlueTheme = localStorage.getItem('blue-theme');
      
      if (newTheme && newTheme !== theme) {
        setTheme(newTheme);
        document.documentElement.classList.toggle('dark', newTheme === 'dark');
      }
      
      if (newBlueTheme !== blueTheme) {
        setBlueTheme(newBlueTheme || "");
        
        // Remove any existing blue theme classes
        document.documentElement.classList.remove(
          'theme-blue-classic', 
          'theme-blue-night',
          'theme-blue-ocean',
          'theme-blue-corporate'
        );
        
        // Add the selected blue theme if not empty
        if (newBlueTheme) {
          const themeClass = `theme-${newBlueTheme.toLowerCase().replace(' ', '-')}`;
          document.documentElement.classList.add(themeClass);
        }
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [theme, blueTheme]);
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
