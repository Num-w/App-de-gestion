
import React from 'react';
import { 
  Calendar, 
  ChefHat, 
  FileText, 
  Home, 
  Package, 
  Settings, 
  ShoppingCart, 
  Users, 
  Wallet,
  Fuel,
  LogOut,
  TrendingDown,
  UserCog,
  TrendingUp
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { useAuth } from '../contexts/AuthContext';
import { useStore } from '../contexts/StoreContext';

interface AppSidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const menuItems = [
  {
    title: 'Tableau de bord',
    icon: Home,
    id: 'dashboard',
    roles: ['admin', 'user', 'manager', 'seller', 'viewer']
  },
  {
    title: 'Gestion Stock',
    icon: Package,
    id: 'products',
    roles: ['admin', 'user', 'manager', 'seller', 'viewer']
  },
  {
    title: 'Ventes',
    icon: ShoppingCart,
    id: 'sales',
    roles: ['admin', 'user', 'manager', 'seller']
  },
  {
    title: 'Gestion Gaz',
    icon: Fuel,
    id: 'gas',
    roles: ['admin', 'user', 'manager', 'seller']
  },
  {
    title: 'Dépenses',
    icon: TrendingDown,
    id: 'expenses',
    roles: ['admin', 'manager']
  },
  {
    title: 'Créances',
    icon: Wallet,
    id: 'debts',
    roles: ['admin', 'user', 'manager']
  },
  {
    title: 'Marge Bénéficiaire',
    icon: TrendingUp,
    id: 'margins',
    roles: ['admin']
  },
  {
    title: 'Rapports',
    icon: FileText,
    id: 'reports',
    roles: ['admin', 'user', 'manager', 'viewer']
  },
  {
    title: 'Mémos',
    icon: Calendar,
    id: 'memos',
    roles: ['admin', 'user', 'manager', 'seller']
  },
  {
    title: 'Gestion Utilisateurs',
    icon: UserCog,
    id: 'users',
    roles: ['admin']
  },
  {
    title: 'Paramètres',
    icon: Settings,
    id: 'settings',
    roles: ['admin']
  }
];

export function AppSidebar({ activeSection, onSectionChange }: AppSidebarProps) {
  const { user, logout } = useAuth();
  const { settings } = useStore();

  const filteredMenuItems = menuItems.filter(item => 
    item.roles.includes(user?.role || 'user')
  );

  return (
    <Sidebar className="border-r border-kitchen-200">
      <SidebarHeader className="p-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <ChefHat className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-lg text-gray-900">{settings.name}</h2>
            <p className="text-sm text-gray-500">v1.0</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredMenuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    isActive={activeSection === item.id}
                    onClick={() => onSectionChange(item.id)}
                    className="w-full justify-start"
                  >
                    <item.icon className="mr-2 h-4 w-4" />
                    <span>{item.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="p-4">
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-8 h-8 bg-kitchen-100 rounded-full flex items-center justify-center">
            <Users className="w-4 h-4 text-kitchen-600" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">{user?.username}</p>
            <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
          </div>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={logout}
          className="w-full justify-start"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Déconnexion
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
