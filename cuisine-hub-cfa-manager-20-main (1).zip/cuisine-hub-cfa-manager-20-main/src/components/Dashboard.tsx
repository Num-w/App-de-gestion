
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { 
  TrendingUp, 
  Package, 
  AlertTriangle, 
  Wallet, 
  Calendar,
  DollarSign,
  ShoppingCart,
  Users,
  RefreshCw,
  Fuel
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

export function Dashboard() {
  const [products] = useLocalStorage('kitchen-store-products', []);
  const [sales] = useLocalStorage('kitchen-store-sales', []);
  const [gasSales] = useLocalStorage('gasSales', []);
  const [gasBottles] = useLocalStorage('gasBottles', []);
  const [debts] = useLocalStorage('debts', []);
  const [settings] = useLocalStorage('kitchen-store-settings', { currency: 'FCFA' });
  const [refreshKey, setRefreshKey] = React.useState(0);
  
  // Force refresh when data changes
  React.useEffect(() => {
    setRefreshKey(prev => prev + 1);
  }, [sales, products, gasSales]);
  
  // Calculer les statistiques
  const getDashboardStats = () => {
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    
    // Modifier pour que la semaine commence le lundi
    const startOfWeek = new Date(today);
    const dayOfWeek = today.getDay();
    const daysToSubtract = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Si dimanche (0), soustraire 6, sinon soustraire (jour - 1)
    startOfWeek.setDate(today.getDate() - daysToSubtract);
    startOfWeek.setHours(0, 0, 0, 0);
    
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    // Combiner les ventes de produits et de gaz
    const allSales = [
      ...sales.map(sale => ({ ...sale, type: 'product' })),
      ...gasSales.map(sale => ({ ...sale, type: 'gas' }))
    ];

    const todaysSales = allSales
      .filter(sale => new Date(sale.date) >= startOfDay)
      .reduce((sum, sale) => sum + sale.total, 0);

    const weekSales = allSales
      .filter(sale => new Date(sale.date) >= startOfWeek)
      .reduce((sum, sale) => sum + sale.total, 0);

    const monthSales = allSales
      .filter(sale => new Date(sale.date) >= startOfMonth)
      .reduce((sum, sale) => sum + sale.total, 0);

    const lowStockProducts = products.filter(p => p.quantity <= p.minStock).length;
    
    // Vérifier le stock de gaz minimum (20kg)
    const gasStock = gasBottles.reduce((sum, bottle) => sum + bottle.quantity, 0);
    const isGasStockLow = gasStock <= 20;
    
    const totalDebts = debts.filter(d => d.type === 'customer' && d.status === 'pending')
      .reduce((sum, d) => sum + d.amount, 0);
    const totalCredits = debts.filter(d => d.type === 'supplier' && d.status === 'pending')
      .reduce((sum, d) => sum + d.amount, 0);

    return {
      todaysSales,
      weekSales,
      monthSales,
      totalProducts: products.length,
      lowStockProducts: lowStockProducts + (isGasStockLow ? 1 : 0),
      totalDebts,
      totalCredits,
      gasStock,
      isGasStockLow
    };
  };

  const stats = getDashboardStats();

  // Forcer un nouveau calcul des statistiques
  const forceRefresh = () => {
    setRefreshKey(prev => prev + 1);
    console.log('Dashboard refreshed');
  };

  // Données pour les graphiques (7 derniers jours avec lundi comme premier jour)
  const salesData = React.useMemo(() => {
    const last7Days = [];
    const allSales = [
      ...sales.map(sale => ({ ...sale, type: 'product' })),
      ...gasSales.map(sale => ({ ...sale, type: 'gas' }))
    ];
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayStart = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
      
      const daySales = allSales.filter(sale => {
        const saleDate = new Date(sale.date);
        return saleDate >= dayStart && saleDate < dayEnd;
      });
      
      const total = daySales.reduce((sum, sale) => sum + sale.total, 0);
      
      last7Days.push({
        name: date.toLocaleDateString('fr-FR', { weekday: 'short' }),
        ventes: total
      });
    }
    return last7Days;
  }, [sales, gasSales, refreshKey]);

  const productCategories = React.useMemo(() => {
    const categories = products.reduce((acc, product) => {
      acc[product.category] = (acc[product.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(categories).map(([name, value]) => ({ name, value }));
  }, [products, refreshKey]);

  const lowStockProducts = products.filter(p => p.quantity <= p.minStock);

  const COLORS = ['#ed7a0b', '#f6b96a', '#de6006', '#b84709', '#792f0f'];

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tableau de bord</h1>
          <p className="text-gray-600">Vue d'ensemble de votre magasin</p>
        </div>
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            onClick={forceRefresh}
            className="flex items-center"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Actualiser
          </Button>
          <div className="text-right">
            <p className="text-sm text-gray-500">Dernière mise à jour</p>
            <p className="text-sm font-medium">{new Date().toLocaleString('fr-FR')}</p>
          </div>
        </div>
      </div>

      {/* Alerte stock gaz minimum */}
      {stats.isGasStockLow && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-red-800">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-medium">
                Alerte: Stock de gaz minimum atteint ({stats.gasStock}kg restant)
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Métriques principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventes du jour</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.todaysSales.toLocaleString()} {settings.currency}</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="inline h-3 w-3 mr-1" />
              Temps réel
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ventes du mois</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.monthSales.toLocaleString()} {settings.currency}</div>
            <p className="text-xs text-muted-foreground">
              Semaine: {stats.weekSales.toLocaleString()} {settings.currency}
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Produits en stock</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalProducts}</div>
            <p className="text-xs text-muted-foreground">
              {stats.lowStockProducts} alertes de stock
            </p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Gaz</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.gasStock}kg</div>
            <p className="text-xs text-muted-foreground">
              {stats.isGasStockLow ? 'Stock minimum!' : 'Stock normal'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Évolution des ventes (7 derniers jours)</CardTitle>
            <CardDescription>
              Analyse des performances de vente (produits + gaz)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value} ${settings.currency}`, 'Ventes']} />
                <Bar dataKey="ventes" fill="#ed7a0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Répartition par catégorie</CardTitle>
            <CardDescription>
              Distribution des produits par catégorie
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={productCategories}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                >
                  {productCategories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alertes et activité récente */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5 text-orange-500" />
              Alertes de stock
            </CardTitle>
            <CardDescription>
              Produits nécessitant un réapprovisionnement
            </CardDescription>
          </CardHeader>
          <CardContent>
            {lowStockProducts.length === 0 && !stats.isGasStockLow ? (
              <p className="text-center text-gray-500 py-4">
                Aucune alerte de stock en cours
              </p>
            ) : (
              <div className="space-y-3">
                {stats.isGasStockLow && (
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">Stock de gaz minimum</p>
                      <p className="text-xs text-gray-500">Butane</p>
                    </div>
                    <Badge variant="destructive">
                      {stats.gasStock}kg restant
                    </Badge>
                  </div>
                )}
                {lowStockProducts.slice(0, 5).map((product) => (
                  <div key={product.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{product.name}</p>
                      <p className="text-xs text-gray-500">{product.category}</p>
                    </div>
                    <Badge variant="destructive">
                      {product.quantity} restant(s)
                    </Badge>
                  </div>
                ))}
                {lowStockProducts.length > 5 && (
                  <p className="text-center text-sm text-gray-500">
                    +{lowStockProducts.length - 5} autres produits
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Activité récente</CardTitle>
            <CardDescription>
              Dernières ventes effectuées
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {/* Combiner et afficher les ventes récentes */}
              {[...sales, ...gasSales]
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 5)
                .map((sale, index) => (
                <div key={`${sale.id}-${index}`} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <ShoppingCart className="h-4 w-4 text-green-500" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      Vente à {sale.customerName}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(sale.date).toLocaleString('fr-FR')}
                      {gasSales.find(gs => gs.id === sale.id) && ' (Gaz)'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">
                      {sale.total.toLocaleString()} {settings.currency}
                    </p>
                  </div>
                </div>
              ))}
              {sales.length === 0 && gasSales.length === 0 && (
                <p className="text-center text-gray-500 py-4">
                  Aucune vente récente
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
