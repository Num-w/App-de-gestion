import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Trash2, Plus, CreditCard, User, Building, Phone } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Debt, Payment } from '../types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';

export function DebtsManagement() {
  const { user } = useAuth();
  const [debts, setDebts] = useLocalStorage<Debt[]>('debts', []);
  const [newDebt, setNewDebt] = useState({
    type: 'customer' as 'customer' | 'supplier',
    name: '',
    phone: '',
    amount: 0,
    description: '',
    dueDate: ''
  });
  const [newPayment, setNewPayment] = useState({
    debtId: '',
    amount: 0,
    method: 'cash' as 'cash' | 'transfer' | 'check'
  });
  const [dialogOpen, setDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const { toast } = useToast();

  const addDebt = () => {
    if (!newDebt.name || !newDebt.amount || !newDebt.dueDate) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    const debt: Debt = {
      id: Date.now().toString(),
      type: newDebt.type,
      name: newDebt.name,
      phone: newDebt.phone,
      amount: newDebt.amount,
      createdDate: new Date(),
      dueDate: new Date(newDebt.dueDate),
      status: 'pending',
      description: newDebt.description,
      payments: []
    };

    setDebts([...debts, debt]);
    setNewDebt({
      type: 'customer',
      name: '',
      phone: '',
      amount: 0,
      description: '',
      dueDate: ''
    });
    setDialogOpen(false);

    toast({
      title: "Créance ajoutée",
      description: `${debt.type === 'customer' ? 'Dette client' : 'Créance fournisseur'} ajoutée avec succès`,
    });
  };

  const addPayment = () => {
    if (!newPayment.debtId || !newPayment.amount) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs",
        variant: "destructive"
      });
      return;
    }

    const payment: Payment = {
      id: Date.now().toString(),
      amount: newPayment.amount,
      date: new Date(),
      method: newPayment.method
    };

    setDebts(debts.map(debt => {
      if (debt.id === newPayment.debtId) {
        const updatedPayments = [...debt.payments, payment];
        const totalPaid = updatedPayments.reduce((sum, p) => sum + p.amount, 0);
        
        let status: 'pending' | 'paid' | 'partial' = 'pending';
        if (totalPaid >= debt.amount) {
          status = 'paid';
        } else if (totalPaid > 0) {
          status = 'partial';
        }

        return {
          ...debt,
          payments: updatedPayments,
          status
        };
      }
      return debt;
    }));

    setNewPayment({
      debtId: '',
      amount: 0,
      method: 'cash'
    });
    setPaymentDialogOpen(false);

    toast({
      title: "Paiement enregistré",
      description: "Le paiement a été ajouté avec succès",
    });
  };

  const deleteDebt = (id: string) => {
    setDebts(debts.filter(d => d.id !== id));
    toast({
      title: "Créance supprimée",
      description: "La créance a été supprimée avec succès",
    });
  };

  const getStatusBadge = (status: 'pending' | 'paid' | 'partial') => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Payé</Badge>;
      case 'partial':
        return <Badge className="bg-yellow-100 text-yellow-800">Partiel</Badge>;
      default:
        return <Badge className="bg-red-100 text-red-800">En attente</Badge>;
    }
  };

  const getTotalPaid = (debt: Debt) => {
    return debt.payments.reduce((sum, payment) => sum + payment.amount, 0);
  };

  const getRemainingAmount = (debt: Debt) => {
    return debt.amount - getTotalPaid(debt);
  };

  const customerDebts = debts.filter(d => d.type === 'customer');
  const supplierDebts = debts.filter(d => d.type === 'supplier');
  const isAdmin = user?.role === 'admin';

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestion des Créances</h2>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nouvelle Créance
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[80vh]">
            <DialogHeader>
              <DialogTitle>Ajouter une nouvelle créance</DialogTitle>
              <DialogDescription>
                Enregistrez une nouvelle dette client ou créance fournisseur
              </DialogDescription>
            </DialogHeader>
            <ScrollArea className="max-h-[60vh] pr-4">
              <div className="space-y-4">
                <div>
                  <Label>Type</Label>
                  <Select value={newDebt.type} onValueChange={(value: 'customer' | 'supplier') => setNewDebt({...newDebt, type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="customer">Dette client</SelectItem>
                      <SelectItem value="supplier">Créance fournisseur</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Nom</Label>
                  <Input
                    value={newDebt.name}
                    onChange={(e) => setNewDebt({...newDebt, name: e.target.value})}
                    placeholder="Nom du client/fournisseur"
                  />
                </div>
                <div>
                  <Label>Téléphone (optionnel)</Label>
                  <Input
                    value={newDebt.phone}
                    onChange={(e) => setNewDebt({...newDebt, phone: e.target.value})}
                    placeholder="Numéro de téléphone"
                  />
                </div>
                <div>
                  <Label>Montant (FCFA)</Label>
                  <Input
                    type="number"
                    value={newDebt.amount}
                    onChange={(e) => setNewDebt({...newDebt, amount: Number(e.target.value)})}
                    placeholder="Montant de la créance"
                  />
                </div>
                <div>
                  <Label>Date d'échéance</Label>
                  <Input
                    type="date"
                    value={newDebt.dueDate}
                    onChange={(e) => setNewDebt({...newDebt, dueDate: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={newDebt.description}
                    onChange={(e) => setNewDebt({...newDebt, description: e.target.value})}
                    placeholder="Description de la créance"
                  />
                </div>
                <Button onClick={addDebt} className="w-full">
                  Ajouter la créance
                </Button>
              </div>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <User className="w-5 h-5 mr-2" />
              Dettes Clients ({customerDebts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {customerDebts.map((debt) => (
                <div key={debt.id} className="p-3 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium">{debt.name}</h4>
                      {debt.phone && (
                        <div className="flex items-center text-sm text-gray-500">
                          <Phone className="w-3 h-3 mr-1" />
                          {debt.phone}
                        </div>
                      )}
                      <p className="text-sm text-gray-500">{debt.description}</p>
                    </div>
                    <div className="text-right">
                      {getStatusBadge(debt.status)}
                      {isAdmin && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteDebt(debt.id)}
                          className="ml-2"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="text-sm">
                    <div className="flex justify-between">
                      <span>Montant total:</span>
                      <span className="font-medium">{debt.amount.toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Payé:</span>
                      <span className="text-green-600">{getTotalPaid(debt).toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Restant:</span>
                      <span className="text-red-600">{getRemainingAmount(debt).toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Échéance:</span>
                      <span>{new Date(debt.dueDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                  {debt.status !== 'paid' && (
                    <Button
                      size="sm"
                      className="mt-2 w-full"
                      onClick={() => {
                        setNewPayment({...newPayment, debtId: debt.id});
                        setPaymentDialogOpen(true);
                      }}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Ajouter un paiement
                    </Button>
                  )}
                </div>
              ))}
              {customerDebts.length === 0 && (
                <p className="text-center text-gray-500 py-4">Aucune dette client</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Building className="w-5 h-5 mr-2" />
              Créances Fournisseurs ({supplierDebts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {supplierDebts.map((debt) => (
                <div key={debt.id} className="p-3 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium">{debt.name}</h4>
                      {debt.phone && (
                        <div className="flex items-center text-sm text-gray-500">
                          <Phone className="w-3 h-3 mr-1" />
                          {debt.phone}
                        </div>
                      )}
                      <p className="text-sm text-gray-500">{debt.description}</p>
                    </div>
                    <div className="text-right">
                      {getStatusBadge(debt.status)}
                      {isAdmin && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteDebt(debt.id)}
                          className="ml-2"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="text-sm">
                    <div className="flex justify-between">
                      <span>Montant total:</span>
                      <span className="font-medium">{debt.amount.toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Reçu:</span>
                      <span className="text-green-600">{getTotalPaid(debt).toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Restant:</span>
                      <span className="text-red-600">{getRemainingAmount(debt).toLocaleString()} FCFA</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Échéance:</span>
                      <span>{new Date(debt.dueDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                  {debt.status !== 'paid' && (
                    <Button
                      size="sm"
                      className="mt-2 w-full"
                      onClick={() => {
                        setNewPayment({...newPayment, debtId: debt.id});
                        setPaymentDialogOpen(true);
                      }}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Ajouter un paiement
                    </Button>
                  )}
                </div>
              ))}
              {supplierDebts.length === 0 && (
                <p className="text-center text-gray-500 py-4">Aucune créance fournisseur</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dialog pour ajouter un paiement */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajouter un paiement</DialogTitle>
            <DialogDescription>
              Enregistrez un nouveau paiement pour cette créance
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Montant (FCFA)</Label>
              <Input
                type="number"
                value={newPayment.amount}
                onChange={(e) => setNewPayment({...newPayment, amount: Number(e.target.value)})}
                placeholder="Montant du paiement"
              />
            </div>
            <div>
              <Label>Mode de paiement</Label>
              <Select value={newPayment.method} onValueChange={(value: 'cash' | 'transfer' | 'check') => setNewPayment({...newPayment, method: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Espèces</SelectItem>
                  <SelectItem value="transfer">Virement</SelectItem>
                  <SelectItem value="check">Chèque</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button onClick={addPayment} className="w-full">
              Enregistrer le paiement
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
