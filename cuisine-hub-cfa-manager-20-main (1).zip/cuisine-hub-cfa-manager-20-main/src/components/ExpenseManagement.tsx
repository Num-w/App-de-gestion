
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Trash2, Plus, Edit, Calendar, TrendingDown, Package, Users, Truck } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';

interface Expense {
  id: string;
  type: 'operational' | 'supplier' | 'delivery' | 'maintenance' | 'other';
  amount: number;
  description: string;
  date: Date;
  supplier?: string;
  category: string;
  paymentMethod: 'cash' | 'transfer' | 'check';
  createdBy: string;
  createdAt: Date;
}

interface Supplier {
  id: string;
  name: string;
  contact: string;
  email?: string;
  address?: string;
  category: string;
  createdAt: Date;
}

interface Delivery {
  id: string;
  supplierId: string;
  supplierName: string;
  items: string[];
  totalAmount: number;
  deliveryDate: Date;
  status: 'pending' | 'delivered' | 'cancelled';
  notes?: string;
  createdBy: string;
  createdAt: Date;
}

export function ExpenseManagement() {
  const { user } = useAuth();
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('kitchen-store-expenses', []);
  const [suppliers, setSuppliers] = useLocalStorage<Supplier[]>('kitchen-store-suppliers', []);
  const [deliveries, setDeliveries] = useLocalStorage<Delivery[]>('kitchen-store-deliveries', []);
  const [isExpenseDialogOpen, setIsExpenseDialogOpen] = useState(false);
  const [isSupplierDialogOpen, setIsSupplierDialogOpen] = useState(false);
  const [isDeliveryDialogOpen, setIsDeliveryDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [editingDelivery, setEditingDelivery] = useState<Delivery | null>(null);
  const [activeTab, setActiveTab] = useState('daily');
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const { toast } = useToast();

  const [expenseFormData, setExpenseFormData] = useState({
    type: 'operational' as const,
    amount: 0,
    description: '',
    supplier: '',
    category: '',
    paymentMethod: 'cash' as const
  });

  const [supplierFormData, setSupplierFormData] = useState({
    name: '',
    contact: '',
    email: '',
    address: '',
    category: ''
  });

  const [deliveryFormData, setDeliveryFormData] = useState({
    supplierId: '',
    items: [''],
    totalAmount: 0,
    deliveryDate: new Date().toISOString().split('T')[0],
    status: 'pending' as const,
    notes: ''
  });

  useEffect(() => {
    if (editingExpense) {
      setExpenseFormData({
        type: editingExpense.type,
        amount: editingExpense.amount,
        description: editingExpense.description,
        supplier: editingExpense.supplier || '',
        category: editingExpense.category,
        paymentMethod: editingExpense.paymentMethod
      });
    } else {
      setExpenseFormData({
        type: 'operational',
        amount: 0,
        description: '',
        supplier: '',
        category: '',
        paymentMethod: 'cash'
      });
    }
  }, [editingExpense]);

  useEffect(() => {
    if (editingSupplier) {
      setSupplierFormData({
        name: editingSupplier.name,
        contact: editingSupplier.contact,
        email: editingSupplier.email || '',
        address: editingSupplier.address || '',
        category: editingSupplier.category
      });
    } else {
      setSupplierFormData({
        name: '',
        contact: '',
        email: '',
        address: '',
        category: ''
      });
    }
  }, [editingSupplier]);

  const handleExpenseSubmit = () => {
    if (!expenseFormData.description || !expenseFormData.amount || !expenseFormData.category) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    if (editingExpense) {
      const updatedExpenses = expenses.map(e => 
        e.id === editingExpense.id 
          ? { ...e, ...expenseFormData, date: new Date() }
          : e
      );
      setExpenses(updatedExpenses);
      toast({
        title: "Dépense modifiée",
        description: "La dépense a été mise à jour avec succès",
      });
    } else {
      const newExpense: Expense = {
        id: Date.now().toString(),
        ...expenseFormData,
        date: new Date(),
        createdBy: user?.username || 'Inconnu',
        createdAt: new Date()
      };
      setExpenses([...expenses, newExpense]);
      toast({
        title: "Dépense ajoutée",
        description: "La nouvelle dépense a été enregistrée",
      });
    }

    setIsExpenseDialogOpen(false);
    setEditingExpense(null);
  };

  const handleSupplierSubmit = () => {
    if (!supplierFormData.name || !supplierFormData.contact) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    if (editingSupplier) {
      const updatedSuppliers = suppliers.map(s => 
        s.id === editingSupplier.id 
          ? { ...s, ...supplierFormData }
          : s
      );
      setSuppliers(updatedSuppliers);
      toast({
        title: "Fournisseur modifié",
        description: "Les informations ont été mises à jour",
      });
    } else {
      const newSupplier: Supplier = {
        id: Date.now().toString(),
        ...supplierFormData,
        createdAt: new Date()
      };
      setSuppliers([...suppliers, newSupplier]);
      toast({
        title: "Fournisseur ajouté",
        description: "Le nouveau fournisseur a été enregistré",
      });
    }

    setIsSupplierDialogOpen(false);
    setEditingSupplier(null);
  };

  const filterExpensesByPeriod = (period: string) => {
    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfWeek = new Date(startOfDay);
    startOfWeek.setDate(startOfDay.getDate() - startOfDay.getDay() + 1); // Lundi
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    return expenses.filter(expense => {
      const expenseDate = new Date(expense.date);
      switch (period) {
        case 'today':
          return expenseDate >= startOfDay;
        case 'week':
          return expenseDate >= startOfWeek;
        case 'month':
          return expenseDate >= startOfMonth;
        case 'year':
          return expenseDate >= startOfYear;
        default:
          return true;
      }
    });
  };

  const calculateTotalExpenses = (period: string) => {
    const filteredExpenses = filterExpensesByPeriod(period);
    return filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  };

  const getExpenseTypeLabel = (type: string) => {
    const labels = {
      operational: 'Opérationnelle',
      supplier: 'Fournisseur',
      delivery: 'Livraison',
      maintenance: 'Maintenance',
      other: 'Autre'
    };
    return labels[type as keyof typeof labels] || type;
  };

  const getExpenseTypeColor = (type: string) => {
    const colors = {
      operational: 'bg-blue-100 text-blue-800',
      supplier: 'bg-green-100 text-green-800',
      delivery: 'bg-yellow-100 text-yellow-800',
      maintenance: 'bg-red-100 text-red-800',
      other: 'bg-gray-100 text-gray-800'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const handleDeleteExpense = (expenseId: string) => {
    setExpenses(expenses.filter(e => e.id !== expenseId));
    toast({
      title: "Dépense supprimée",
      description: "La dépense a été supprimée avec succès",
    });
  };

  const handleDeleteSupplier = (supplierId: string) => {
    // Vérifier si le fournisseur est utilisé dans des dépenses
    const usedInExpenses = expenses.some(e => e.supplier === suppliers.find(s => s.id === supplierId)?.name);
    if (usedInExpenses) {
      toast({
        title: "Impossible de supprimer",
        description: "Ce fournisseur est utilisé dans des dépenses existantes",
        variant: "destructive"
      });
      return;
    }

    setSuppliers(suppliers.filter(s => s.id !== supplierId));
    toast({
      title: "Fournisseur supprimé",
      description: "Le fournisseur a été supprimé avec succès",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestion des Dépenses</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="daily">Journalier</TabsTrigger>
          <TabsTrigger value="weekly">Hebdomadaire</TabsTrigger>
          <TabsTrigger value="monthly">Mensuel</TabsTrigger>
          <TabsTrigger value="yearly">Annuel</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingDown className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-600">Aujourd'hui</p>
                    <p className="text-2xl font-bold">{calculateTotalExpenses('today').toLocaleString()} FCFA</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Dépenses du jour</h3>
            <Dialog open={isExpenseDialogOpen} onOpenChange={setIsExpenseDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => setEditingExpense(null)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Nouvelle Dépense
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingExpense ? 'Modifier la dépense' : 'Nouvelle dépense'}
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label>Type de dépense</Label>
                    <Select value={expenseFormData.type} onValueChange={(value: any) => setExpenseFormData({...expenseFormData, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="operational">Opérationnelle</SelectItem>
                        <SelectItem value="supplier">Fournisseur</SelectItem>
                        <SelectItem value="delivery">Livraison</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Montant (FCFA)</Label>
                    <Input
                      type="number"
                      value={expenseFormData.amount}
                      onChange={(e) => setExpenseFormData({...expenseFormData, amount: Number(e.target.value)})}
                      placeholder="Montant"
                    />
                  </div>

                  <div>
                    <Label>Description</Label>
                    <Input
                      value={expenseFormData.description}
                      onChange={(e) => setExpenseFormData({...expenseFormData, description: e.target.value})}
                      placeholder="Description de la dépense"
                    />
                  </div>

                  <div>
                    <Label>Catégorie</Label>
                    <Input
                      value={expenseFormData.category}
                      onChange={(e) => setExpenseFormData({...expenseFormData, category: e.target.value})}
                      placeholder="Catégorie"
                    />
                  </div>

                  {expenseFormData.type === 'supplier' && (
                    <div>
                      <Label>Fournisseur</Label>
                      <Select value={expenseFormData.supplier} onValueChange={(value) => setExpenseFormData({...expenseFormData, supplier: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choisir un fournisseur" />
                        </SelectTrigger>
                        <SelectContent>
                          {suppliers.map((supplier) => (
                            <SelectItem key={supplier.id} value={supplier.name}>
                              {supplier.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  <div>
                    <Label>Méthode de paiement</Label>
                    <Select value={expenseFormData.paymentMethod} onValueChange={(value: any) => setExpenseFormData({...expenseFormData, paymentMethod: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Espèces</SelectItem>
                        <SelectItem value="transfer">Virement</SelectItem>
                        <SelectItem value="check">Chèque</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={handleExpenseSubmit} className="w-full">
                    {editingExpense ? 'Modifier' : 'Ajouter'} la dépense
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Catégorie</TableHead>
                    <TableHead>Montant</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filterExpensesByPeriod('today').map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell>{new Date(expense.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={getExpenseTypeColor(expense.type)}>
                          {getExpenseTypeLabel(expense.type)}
                        </Badge>
                      </TableCell>
                      <TableCell>{expense.description}</TableCell>
                      <TableCell>{expense.category}</TableCell>
                      <TableCell>{expense.amount.toLocaleString()} FCFA</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setEditingExpense(expense);
                              setIsExpenseDialogOpen(true);
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteExpense(expense.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filterExpensesByPeriod('today').length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                        Aucune dépense pour aujourd'hui
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Autres onglets similaires pour weekly, monthly, yearly */}
        <TabsContent value="weekly" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingDown className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-600">Cette semaine</p>
                    <p className="text-2xl font-bold">{calculateTotalExpenses('week').toLocaleString()} FCFA</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Table similaire pour les dépenses hebdomadaires */}
        </TabsContent>

        <TabsContent value="monthly" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingDown className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-600">Ce mois</p>
                    <p className="text-2xl font-bold">{calculateTotalExpenses('month').toLocaleString()} FCFA</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Table similaire pour les dépenses mensuelles */}
        </TabsContent>

        <TabsContent value="yearly" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingDown className="w-5 h-5 text-red-500" />
                  <div>
                    <p className="text-sm text-gray-600">Cette année</p>
                    <p className="text-2xl font-bold">{calculateTotalExpenses('year').toLocaleString()} FCFA</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Table similaire pour les dépenses annuelles */}
        </TabsContent>
      </Tabs>

      {/* Section Fournisseurs */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-semibold">Gestion des Fournisseurs</h3>
          <Dialog open={isSupplierDialogOpen} onOpenChange={setIsSupplierDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setEditingSupplier(null)}>
                <Plus className="w-4 h-4 mr-2" />
                Nouveau Fournisseur
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {editingSupplier ? 'Modifier le fournisseur' : 'Nouveau fournisseur'}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Nom du fournisseur</Label>
                  <Input
                    value={supplierFormData.name}
                    onChange={(e) => setSupplierFormData({...supplierFormData, name: e.target.value})}
                    placeholder="Nom du fournisseur"
                  />
                </div>

                <div>
                  <Label>Contact</Label>
                  <Input
                    value={supplierFormData.contact}
                    onChange={(e) => setSupplierFormData({...supplierFormData, contact: e.target.value})}
                    placeholder="Numéro de téléphone"
                  />
                </div>

                <div>
                  <Label>Email (optionnel)</Label>
                  <Input
                    type="email"
                    value={supplierFormData.email}
                    onChange={(e) => setSupplierFormData({...supplierFormData, email: e.target.value})}
                    placeholder="Email"
                  />
                </div>

                <div>
                  <Label>Adresse (optionnel)</Label>
                  <Input
                    value={supplierFormData.address}
                    onChange={(e) => setSupplierFormData({...supplierFormData, address: e.target.value})}
                    placeholder="Adresse"
                  />
                </div>

                <div>
                  <Label>Catégorie</Label>
                  <Input
                    value={supplierFormData.category}
                    onChange={(e) => setSupplierFormData({...supplierFormData, category: e.target.value})}
                    placeholder="Catégorie (ex: Alimentaire, Équipement)"
                  />
                </div>

                <Button onClick={handleSupplierSubmit} className="w-full">
                  {editingSupplier ? 'Modifier' : 'Ajouter'} le fournisseur
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nom</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Catégorie</TableHead>
                  <TableHead>Date création</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {suppliers.map((supplier) => (
                  <TableRow key={supplier.id}>
                    <TableCell className="font-medium">{supplier.name}</TableCell>
                    <TableCell>{supplier.contact}</TableCell>
                    <TableCell>{supplier.email || '-'}</TableCell>
                    <TableCell>{supplier.category}</TableCell>
                    <TableCell>{new Date(supplier.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingSupplier(supplier);
                            setIsSupplierDialogOpen(true);
                          }}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteSupplier(supplier.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {suppliers.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-gray-500 py-8">
                      Aucun fournisseur enregistré
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
