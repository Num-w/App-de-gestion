import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Fuel, Plus, ShoppingCart, AlertTriangle } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { GasBottle, GasSale, Debt } from '../types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function GasManagement() {
  const [gasBottles, setGasBottles] = useLocalStorage<GasBottle[]>('gasBottles', []);
  const [gasSales, setGasSales] = useLocalStorage<GasSale[]>('gasSales', []);
  const [debts, setDebts] = useLocalStorage<Debt[]>('debts', []);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isSaleDialogOpen, setIsSaleDialogOpen] = useState(false);
  const { toast } = useToast();

  const [newBottle, setNewBottle] = useState({
    size: '50kg',
    units: 0,
    purchasePrice: 0,
    supplier: ''
  });

  const [newExchange, setNewExchange] = useState({
    size: '12kg',
    units: 0,
    purchasePrice: 0,
    exchangePrice: 0,
    supplier: ''
  });

  const [saleData, setSaleData] = useState({
    type: 'detail',
    quantity: 0,
    amount: 0,
    customerName: '',
    customerContact: '',
    paymentMethod: 'cash' as 'cash' | 'credit'
  });

  // Vérifier le stock minimum de 20kg
  useEffect(() => {
    const totalStock = gasBottles
      .filter(bottle => !bottle.isExchange)
      .reduce((sum, bottle) => sum + bottle.quantity, 0);

    if (totalStock <= 20 && totalStock > 0) {
      toast({
        title: "Alerte Stock Minimum",
        description: `Stock de gaz faible: ${totalStock}kg restant (minimum: 20kg)`,
        variant: "destructive"
      });
    }
  }, [gasBottles, toast]);

  const handleAddBottle = () => {
    if (newBottle.units <= 0 || newBottle.purchasePrice <= 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    const sizeValue = 50;
    const totalQuantity = newBottle.units * sizeValue;

    const bottle: GasBottle = {
      id: Date.now().toString(),
      type: 'Butane',
      size: '50kg',
      quantity: totalQuantity,
      units: newBottle.units,
      purchasePrice: newBottle.purchasePrice,
      salePrice: newBottle.purchasePrice * 1.2,
      supplier: newBottle.supplier,
      deliveryDate: new Date(),
      isExchange: false
    };

    setGasBottles([...gasBottles, bottle]);
    setNewBottle({
      size: '50kg',
      units: 0,
      purchasePrice: 0,
      supplier: ''
    });
    setIsAddDialogOpen(false);
    toast({
      title: "Livraison ajoutée",
      description: `${newBottle.units} bouteilles de 50kg ajoutées (${totalQuantity}kg total)`,
    });
  };

  const handleAddExchange = () => {
    if (newExchange.units <= 0 || newExchange.purchasePrice <= 0 || newExchange.exchangePrice <= 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    const sizeValue = parseInt(newExchange.size.replace('kg', ''));
    const totalQuantity = newExchange.units * sizeValue;

    const bottle: GasBottle = {
      id: Date.now().toString(),
      type: 'Butane',
      size: newExchange.size,
      quantity: totalQuantity,
      units: newExchange.units,
      purchasePrice: newExchange.purchasePrice,
      salePrice: newExchange.exchangePrice,
      supplier: newExchange.supplier,
      deliveryDate: new Date(),
      isExchange: true,
      exchangePrice: newExchange.exchangePrice
    };

    setGasBottles([...gasBottles, bottle]);
    setNewExchange({
      size: '12kg',
      units: 0,
      purchasePrice: 0,
      exchangePrice: 0,
      supplier: ''
    });
    toast({
      title: "Bouteilles d'échange ajoutées",
      description: `${newExchange.units} bouteilles de ${newExchange.size} pour échange`,
    });
  };

  const handleSale = () => {
    if (saleData.quantity <= 0 || saleData.amount <= 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive"
      });
      return;
    }

    if (saleData.paymentMethod === 'credit' && !saleData.customerName.trim()) {
      toast({
        title: "Erreur",
        description: "Le nom du client est obligatoire pour un paiement à crédit",
        variant: "destructive"
      });
      return;
    }

    if (saleData.type === 'detail') {
      const totalStock = gasBottles
        .filter(b => b.size === '50kg' && !b.isExchange)
        .reduce((sum, bottle) => sum + bottle.quantity, 0);

      if (totalStock < saleData.quantity) {
        toast({
          title: "Stock insuffisant",
          description: `Stock disponible: ${totalStock}kg`,
          variant: "destructive"
        });
        return;
      }
    }

    const sale: GasSale = {
      id: Date.now().toString(),
      bottleType: saleData.type === 'exchange' ? `Échange ${saleData.quantity} bouteilles` : `${saleData.quantity}kg en détail`,
      quantity: saleData.quantity,
      unitPrice: saleData.amount / saleData.quantity,
      total: saleData.amount,
      customerName: saleData.customerName || 'Client anonyme',
      customerContact: saleData.customerContact || '',
      date: new Date(),
      paymentMethod: saleData.paymentMethod,
      isExchange: saleData.type === 'exchange'
    };

    if (saleData.type === 'detail') {
      let remainingToDeduct = saleData.quantity;
      const updatedBottles = gasBottles.map(bottle => {
        if (bottle.size === '50kg' && !bottle.isExchange && remainingToDeduct > 0) {
          const deduction = Math.min(bottle.quantity, remainingToDeduct);
          remainingToDeduct -= deduction;
          return { ...bottle, quantity: bottle.quantity - deduction };
        }
        return bottle;
      });
      setGasBottles(updatedBottles);
    } else if (saleData.type === 'exchange') {
      const updatedBottles = gasBottles.map(bottle => {
        if (bottle.isExchange && bottle.units >= saleData.quantity) {
          const sizeValue = parseInt(bottle.size.replace('kg', ''));
          const totalQuantityDeducted = saleData.quantity * sizeValue;
          return { 
            ...bottle, 
            units: bottle.units - saleData.quantity,
            quantity: bottle.quantity - totalQuantityDeducted
          };
        }
        return bottle;
      });
      setGasBottles(updatedBottles);
    }

    setGasSales([...gasSales, sale]);

    if (saleData.paymentMethod === 'credit') {
      const debt: Debt = {
        id: Date.now().toString() + '_debt',
        type: 'customer',
        name: saleData.customerName,
        phone: saleData.customerContact,
        amount: saleData.amount,
        createdDate: new Date(),
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        status: 'pending',
        description: `Vente de gaz - ${sale.bottleType}`,
        payments: []
      };
      setDebts([...debts, debt]);
    }

    setSaleData({
      type: 'detail',
      quantity: 0,
      amount: 0,
      customerName: '',
      customerContact: '',
      paymentMethod: 'cash'
    });
    setIsSaleDialogOpen(false);

    toast({
      title: "Vente enregistrée",
      description: `Vente de ${sale.total} FCFA enregistrée avec succès`,
    });
  };

  // Calculs pour les statistiques
  const detailBottles = gasBottles.filter(b => !b.isExchange);
  const exchangeBottles = gasBottles.filter(b => b.isExchange);
  
  const totalDetailStock = detailBottles.reduce((sum, bottle) => sum + bottle.quantity, 0);
  const totalDetailUnits = detailBottles.reduce((sum, bottle) => sum + bottle.units, 0);
  
  // Calculer le montant total (prix d'achat pour vente en détail + échange)
  const detailTotalAmount = detailBottles.reduce((sum, bottle) => sum + (bottle.units * bottle.purchasePrice), 0);
  const exchangeTotalAmount = exchangeBottles.reduce((sum, bottle) => sum + (bottle.units * bottle.purchasePrice), 0);
  const totalStockValue = detailTotalAmount + exchangeTotalAmount;

  const exchange12kg = exchangeBottles.filter(b => b.size === '12kg').reduce((sum, b) => sum + b.units, 0);
  const exchange6kg = exchangeBottles.filter(b => b.size === '6kg').reduce((sum, b) => sum + b.units, 0);

  // Calculer les montants totaux pour l'affichage dans les onglets
  const detailTotalInDialog = newBottle.units * newBottle.purchasePrice;
  const exchangeTotalInDialog = newExchange.units * newExchange.purchasePrice;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestion du Gaz</h2>
        <div className="flex space-x-2">
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Nouvelle livraison
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Ajouter une livraison de gaz</DialogTitle>
              </DialogHeader>
              <Tabs defaultValue="detail" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="detail">Vente en détail (50kg)</TabsTrigger>
                  <TabsTrigger value="exchange">Échange (12kg/6kg)</TabsTrigger>
                </TabsList>
                
                <TabsContent value="detail" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Type de gaz</Label>
                      <Input value="Butane" disabled className="bg-gray-100" />
                    </div>
                    <div>
                      <Label>Taille</Label>
                      <Input value="50kg" disabled className="bg-gray-100" />
                    </div>
                  </div>
                  <div>
                    <Label>Unités (nombre de bouteilles)</Label>
                    <Input
                      type="number"
                      value={newBottle.units}
                      onChange={(e) => setNewBottle({...newBottle, units: parseInt(e.target.value) || 0})}
                    />
                    {newBottle.units > 0 && (
                      <p className="text-sm text-gray-500 mt-1">
                        Stock total: {newBottle.units * 50}kg ({newBottle.units} bouteilles de 50kg)
                      </p>
                    )}
                  </div>
                  <div>
                    <Label>Prix d'achat par bouteille (FCFA)</Label>
                    <Input
                      type="number"
                      value={newBottle.purchasePrice}
                      onChange={(e) => setNewBottle({...newBottle, purchasePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Fournisseur</Label>
                    <Input
                      value={newBottle.supplier}
                      onChange={(e) => setNewBottle({...newBottle, supplier: e.target.value})}
                    />
                  </div>
                  {detailTotalInDialog > 0 && (
                    <div className="bg-blue-50 p-3 rounded-lg">
                      <p className="font-medium text-blue-800">
                        Montant Total: {detailTotalInDialog.toLocaleString()} FCFA
                      </p>
                      <p className="text-sm text-blue-600">
                        ({newBottle.units} bouteilles × {newBottle.purchasePrice} FCFA)
                      </p>
                    </div>
                  )}
                  <Button onClick={handleAddBottle} className="w-full">
                    Ajouter la livraison
                  </Button>
                </TabsContent>

                <TabsContent value="exchange" className="space-y-4">
                  <div>
                    <Label>Type de gaz</Label>
                    <Input value="Butane" disabled className="bg-gray-100" />
                  </div>
                  <div>
                    <Label>Taille des bouteilles</Label>
                    <Select value={newExchange.size} onValueChange={(value) => setNewExchange({...newExchange, size: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="12kg">12kg</SelectItem>
                        <SelectItem value="6kg">6kg</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Nombre de bouteilles</Label>
                    <Input
                      type="number"
                      value={newExchange.units}
                      onChange={(e) => setNewExchange({...newExchange, units: parseInt(e.target.value) || 0})}
                    />
                    {newExchange.units > 0 && (
                      <p className="text-sm text-gray-500 mt-1">
                        {newExchange.units} bouteilles de {newExchange.size}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label>Prix d'achat par bouteille (FCFA)</Label>
                    <Input
                      type="number"
                      value={newExchange.purchasePrice}
                      onChange={(e) => setNewExchange({...newExchange, purchasePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Prix d'échange par bouteille (FCFA)</Label>
                    <Input
                      type="number"
                      value={newExchange.exchangePrice}
                      onChange={(e) => setNewExchange({...newExchange, exchangePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Fournisseur</Label>
                    <Input
                      value={newExchange.supplier}
                      onChange={(e) => setNewExchange({...newExchange, supplier: e.target.value})}
                    />
                  </div>
                  {exchangeTotalInDialog > 0 && (
                    <div className="bg-green-50 p-3 rounded-lg">
                      <p className="font-medium text-green-800">
                        Montant Total: {exchangeTotalInDialog.toLocaleString()} FCFA
                      </p>
                      <p className="text-sm text-green-600">
                        ({newExchange.units} bouteilles × {newExchange.purchasePrice} FCFA)
                      </p>
                    </div>
                  )}
                  <Button onClick={handleAddExchange} className="w-full">
                    Ajouter les bouteilles d'échange
                  </Button>
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>

          <Dialog open={isSaleDialogOpen} onOpenChange={setIsSaleDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Nouvelle vente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[80vh]">
              <DialogHeader>
                <DialogTitle>Vendre du gaz</DialogTitle>
              </DialogHeader>
              <ScrollArea className="max-h-[60vh] pr-4">
                <div className="space-y-4">
                  <div>
                    <Label>Type de vente</Label>
                    <Select value={saleData.type} onValueChange={(value) => setSaleData({...saleData, type: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="detail">Vente en détail (kg)</SelectItem>
                        <SelectItem value="exchange">Échange de bouteilles</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>
                      {saleData.type === 'exchange' ? 'Nombre de bouteilles' : 'Quantité (kg)'}
                    </Label>
                    <Input
                      type="number"
                      step={saleData.type === 'exchange' ? "1" : "0.1"}
                      min={saleData.type === 'exchange' ? "1" : "0.1"}
                      value={saleData.quantity}
                      onChange={(e) => setSaleData({...saleData, quantity: parseFloat(e.target.value) || 0})}
                      placeholder={saleData.type === 'exchange' ? "Nombre de bouteilles" : "Quantité en kg"}
                    />
                  </div>
                  
                  <div>
                    <Label>Mode de paiement</Label>
                    <Select value={saleData.paymentMethod} onValueChange={(value: 'cash' | 'credit') => setSaleData({...saleData, paymentMethod: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Espèces</SelectItem>
                        <SelectItem value="credit">Crédit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Montant total (FCFA)</Label>
                    <Input
                      type="number"
                      value={saleData.amount}
                      onChange={(e) => setSaleData({...saleData, amount: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  
                  <div>
                    <Label>Nom du client {saleData.paymentMethod === 'credit' && '*'}</Label>
                    <Input
                      value={saleData.customerName}
                      onChange={(e) => setSaleData({...saleData, customerName: e.target.value})}
                      placeholder={saleData.paymentMethod === 'credit' ? "Obligatoire pour crédit" : "Optionnel"}
                    />
                  </div>
                  
                  <div>
                    <Label>Contact (optionnel)</Label>
                    <Input
                      value={saleData.customerContact}
                      onChange={(e) => setSaleData({...saleData, customerContact: e.target.value})}
                    />
                  </div>
                  
                  <Button 
                    onClick={handleSale} 
                    className="w-full" 
                    disabled={saleData.quantity <= 0 || saleData.amount <= 0}
                  >
                    Enregistrer la vente
                  </Button>
                </div>
              </ScrollArea>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {totalDetailStock <= 20 && totalDetailStock > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 text-red-800">
              <AlertTriangle className="w-5 h-5" />
              <span className="font-medium">
                Alerte: Stock minimum atteint ({totalDetailStock}kg restant)
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Fuel className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Stock total détail</p>
                <p className="text-2xl font-bold">{totalDetailStock}kg</p>
                <p className="text-xs text-gray-500">{totalDetailUnits} bouteilles 50kg</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Valeur du stock</p>
              <p className="text-2xl font-bold">{totalStockValue.toLocaleString()} FCFA</p>
              <p className="text-xs text-gray-500">Prix d'achat total (détail + échange)</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Bouteilles échange 12kg</p>
              <p className="text-2xl font-bold">{exchange12kg}</p>
              <p className="text-xs text-gray-500">Disponibles</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Bouteilles échange 6kg</p>
              <p className="text-2xl font-bold">{exchange6kg}</p>
              <p className="text-xs text-gray-500">Disponibles</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Stock de gaz</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {gasBottles.map((bottle) => (
              <Card key={bottle.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold">
                        {bottle.type} {bottle.size}
                        {bottle.isExchange && <Badge className="ml-2">Échange</Badge>}
                      </h3>
                      <Badge variant={bottle.quantity > 0 ? "default" : "secondary"}>
                        {bottle.quantity > 0 ? "Disponible" : "Épuisé"}
                      </Badge>
                    </div>
                    <div className="text-sm space-y-1">
                      {bottle.isExchange ? (
                        <div>Bouteilles: {bottle.units} unités disponibles</div>
                      ) : (
                        <div>Stock: {bottle.quantity}kg ({bottle.units} bouteilles)</div>
                      )}
                      <div>Prix d'achat: {bottle.purchasePrice} FCFA/unité</div>
                      {bottle.isExchange && bottle.exchangePrice && (
                        <div>Prix d'échange: {bottle.exchangePrice} FCFA</div>
                      )}
                      <div>Fournisseur: {bottle.supplier}</div>
                      <div>Livré le: {new Date(bottle.deliveryDate).toLocaleDateString()} à {new Date(bottle.deliveryDate).toLocaleTimeString()}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          {gasBottles.length === 0 && (
            <div className="text-center text-gray-500 py-8">
              Aucune livraison de gaz enregistrée
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ventes de gaz récentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {gasSales.slice(-5).reverse().map((sale) => (
              <div key={sale.id} className="flex justify-between items-center p-2 border rounded">
                <div>
                  <div className="font-medium">{sale.customerName}</div>
                  <div className="text-sm text-gray-500">
                    {sale.bottleType} - {new Date(sale.date).toLocaleDateString()} à {new Date(sale.date).toLocaleTimeString()}
                    <Badge className="ml-2" variant={sale.paymentMethod === 'credit' ? 'destructive' : 'default'}>
                      {sale.paymentMethod === 'credit' ? 'Crédit' : 'Espèces'}
                    </Badge>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold">{sale.total} FCFA</div>
                </div>
              </div>
            ))}
            {gasSales.length === 0 && (
              <div className="text-center text-gray-500 py-4">
                Aucune vente de gaz enregistrée
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
