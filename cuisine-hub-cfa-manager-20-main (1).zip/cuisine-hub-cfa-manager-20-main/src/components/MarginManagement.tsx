
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Package, Fuel, Calculator } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Sale, GasSale, GasBottle } from '../types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export function MarginManagement() {
  const [products] = useLocalStorage<Product[]>('products', []);
  const [sales] = useLocalStorage<Sale[]>('sales', []);
  const [gasSales] = useLocalStorage<GasSale[]>('gasSales', []);
  const [gasBottles] = useLocalStorage<GasBottle[]>('gasBottles', []);

  // Calculer les marges pour les produits
  const calculateProductMargins = () => {
    return products.map(product => {
      const margin = product.salePrice - product.purchasePrice;
      const marginPercentage = product.purchasePrice > 0 ? (margin / product.purchasePrice) * 100 : 0;
      
      // Calculer le total vendu pour ce produit
      const totalSold = sales.reduce((sum, sale) => {
        const productSale = sale.products.find(p => p.productId === product.id);
        return sum + (productSale ? productSale.quantity : 0);
      }, 0);

      const totalRevenue = sales.reduce((sum, sale) => {
        const productSale = sale.products.find(p => p.productId === product.id);
        return sum + (productSale ? productSale.subtotal : 0);
      }, 0);

      const totalCost = totalSold * product.purchasePrice;
      const totalProfit = totalRevenue - totalCost;

      return {
        ...product,
        margin,
        marginPercentage,
        totalSold,
        totalRevenue,
        totalCost,
        totalProfit
      };
    });
  };

  // Calculer les marges pour le gaz
  const calculateGasMargins = () => {
    const gasMargins = gasBottles.map(bottle => {
      const margin = bottle.salePrice - bottle.purchasePrice;
      const marginPercentage = bottle.purchasePrice > 0 ? (margin / bottle.purchasePrice) * 100 : 0;

      // Calculer les ventes pour ce type de bouteille
      const relevantSales = gasSales.filter(sale => 
        (bottle.isExchange && sale.isExchange) || 
        (!bottle.isExchange && !sale.isExchange)
      );

      const totalRevenue = relevantSales.reduce((sum, sale) => sum + sale.total, 0);
      const totalQuantitySold = relevantSales.reduce((sum, sale) => sum + sale.quantity, 0);
      const totalCost = totalQuantitySold * bottle.purchasePrice;
      const totalProfit = totalRevenue - totalCost;

      return {
        ...bottle,
        margin,
        marginPercentage,
        totalQuantitySold,
        totalRevenue,
        totalCost,
        totalProfit
      };
    });

    return gasMargins;
  };

  const productMargins = calculateProductMargins();
  const gasMargins = calculateGasMargins();

  // Calculer les statistiques globales
  const totalProductProfit = productMargins.reduce((sum, p) => sum + p.totalProfit, 0);
  const totalGasProfit = gasMargins.reduce((sum, g) => sum + g.totalProfit, 0);
  const totalProfit = totalProductProfit + totalGasProfit;

  const totalProductRevenue = productMargins.reduce((sum, p) => sum + p.totalRevenue, 0);
  const totalGasRevenue = gasMargins.reduce((sum, g) => sum + g.totalRevenue, 0);
  const totalRevenue = totalProductRevenue + totalGasRevenue;

  const totalProductCost = productMargins.reduce((sum, p) => sum + p.totalCost, 0);
  const totalGasCost = gasMargins.reduce((sum, g) => sum + g.totalCost, 0);
  const totalCost = totalProductCost + totalGasCost;

  const globalMarginPercentage = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;

  // Produits les plus rentables
  const topProfitableProducts = productMargins
    .filter(p => p.totalProfit > 0)
    .sort((a, b) => b.totalProfit - a.totalProfit)
    .slice(0, 5);

  // Produits avec les meilleures marges
  const topMarginProducts = productMargins
    .filter(p => p.marginPercentage > 0)
    .sort((a, b) => b.marginPercentage - a.marginPercentage)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Analyse des Marges Bénéficiaires</h2>

      {/* Statistiques globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calculator className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Bénéfice Total</p>
                <p className="text-2xl font-bold text-green-600">{totalProfit.toLocaleString()} FCFA</p>
                <p className="text-xs text-gray-500">Tous produits confondus</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Chiffre d'Affaires</p>
              <p className="text-2xl font-bold">{totalRevenue.toLocaleString()} FCFA</p>
              <p className="text-xs text-gray-500">Total des ventes</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Coût Total</p>
              <p className="text-2xl font-bold text-red-600">{totalCost.toLocaleString()} FCFA</p>
              <p className="text-xs text-gray-500">Coût d'achat des produits vendus</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Marge Globale</p>
              <p className="text-2xl font-bold">{globalMarginPercentage.toFixed(1)}%</p>
              <p className="text-xs text-gray-500">Rentabilité moyenne</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Répartition par catégorie */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Package className="w-5 h-5 mr-2" />
              Produits Alimentaires
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Bénéfice:</span>
                <span className="font-bold text-green-600">{totalProductProfit.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Chiffre d'affaires:</span>
                <span>{totalProductRevenue.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Coût:</span>
                <span className="text-red-600">{totalProductCost.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Marge moyenne:</span>
                <span className="font-bold">
                  {totalProductCost > 0 ? ((totalProductProfit / totalProductCost) * 100).toFixed(1) : 0}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Fuel className="w-5 h-5 mr-2" />
              Gaz Butane
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Bénéfice:</span>
                <span className="font-bold text-green-600">{totalGasProfit.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Chiffre d'affaires:</span>
                <span>{totalGasRevenue.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Coût:</span>
                <span className="text-red-600">{totalGasCost.toLocaleString()} FCFA</span>
              </div>
              <div className="flex justify-between">
                <span>Marge moyenne:</span>
                <span className="font-bold">
                  {totalGasCost > 0 ? ((totalGasProfit / totalGasCost) * 100).toFixed(1) : 0}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top produits les plus rentables */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Produits les Plus Rentables
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Produit</TableHead>
                <TableHead>Quantité Vendue</TableHead>
                <TableHead>Bénéfice Total</TableHead>
                <TableHead>Marge %</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {topProfitableProducts.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{product.totalSold}</TableCell>
                  <TableCell className="text-green-600 font-bold">
                    {product.totalProfit.toLocaleString()} FCFA
                  </TableCell>
                  <TableCell>
                    <Badge variant={product.marginPercentage > 50 ? "default" : product.marginPercentage > 20 ? "secondary" : "destructive"}>
                      {product.marginPercentage.toFixed(1)}%
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {topProfitableProducts.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              Aucun produit vendu pour le moment
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analyse détaillée des marges */}
      <Card>
        <CardHeader>
          <CardTitle>Analyse Détaillée des Marges par Produit</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Produit</TableHead>
                <TableHead>Prix Achat</TableHead>
                <TableHead>Prix Vente</TableHead>
                <TableHead>Marge Unitaire</TableHead>
                <TableHead>Marge %</TableHead>
                <TableHead>Stock</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {productMargins.map((product) => (
                <TableRow key={product.id}>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell>{product.purchasePrice.toLocaleString()} FCFA</TableCell>
                  <TableCell>{product.salePrice.toLocaleString()} FCFA</TableCell>
                  <TableCell className={product.margin > 0 ? "text-green-600" : "text-red-600"}>
                    {product.margin.toLocaleString()} FCFA
                  </TableCell>
                  <TableCell>
                    <Badge variant={product.marginPercentage > 50 ? "default" : product.marginPercentage > 20 ? "secondary" : "destructive"}>
                      {product.marginPercentage.toFixed(1)}%
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={product.quantity > product.minStock ? "default" : "destructive"}>
                      {product.quantity}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {productMargins.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              Aucun produit enregistré
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
