
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StickyNote, Plus, Edit, Trash2, Calendar } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';
import { Memo } from '../types';

export function MemosManagement() {
  const { user } = useAuth();
  const [memos, setMemos] = useLocalStorage<Memo[]>('memos', []);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingMemo, setEditingMemo] = useState<Memo | null>(null);
  const { toast } = useToast();

  const [newMemo, setNewMemo] = useState({
    title: '',
    content: '',
    priority: 'medium' as const,
    category: 'general' as const
  });

  // Filter memos for current user
  const userMemos = memos.filter(memo => memo.userId === user?.id);

  const handleAddMemo = () => {
    if (!user) return;

    const memo: Memo = {
      id: Date.now().toString(),
      ...newMemo,
      createdAt: new Date(),
      completed: false,
      userId: user.id
    };

    setMemos([...memos, memo]);
    setNewMemo({
      title: '',
      content: '',
      priority: 'medium',
      category: 'general'
    });
    setIsAddDialogOpen(false);
    toast({
      title: "Mémo ajouté",
      description: "Le mémo a été ajouté avec succès",
    });
  };

  const handleUpdateMemo = () => {
    if (!editingMemo) return;
    
    const updatedMemos = memos.map(m => 
      m.id === editingMemo.id ? editingMemo : m
    );
    setMemos(updatedMemos);
    setEditingMemo(null);
    toast({
      title: "Mémo modifié",
      description: "Le mémo a été modifié avec succès",
    });
  };

  const handleDeleteMemo = (id: string) => {
    setMemos(memos.filter(m => m.id !== id));
    toast({
      title: "Mémo supprimé",
      description: "Le mémo a été supprimé avec succès",
    });
  };

  const toggleCompleted = (id: string) => {
    const updatedMemos = memos.map(m => 
      m.id === id ? { ...m, completed: !m.completed } : m
    );
    setMemos(updatedMemos);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'default';
      case 'low': return 'secondary';
      default: return 'default';
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'stock': return 'Stock';
      case 'vente': return 'Vente';
      case 'rappel': return 'Rappel';
      default: return 'Général';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Mes Mémos et Rappels</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nouveau mémo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ajouter un nouveau mémo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Titre</Label>
                <Input
                  value={newMemo.title}
                  onChange={(e) => setNewMemo({...newMemo, title: e.target.value})}
                  placeholder="Titre du mémo"
                />
              </div>
              <div>
                <Label>Contenu</Label>
                <Textarea
                  value={newMemo.content}
                  onChange={(e) => setNewMemo({...newMemo, content: e.target.value})}
                  placeholder="Détails du mémo"
                  rows={4}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Priorité</Label>
                  <Select value={newMemo.priority} onValueChange={(value: any) => setNewMemo({...newMemo, priority: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Faible</SelectItem>
                      <SelectItem value="medium">Moyenne</SelectItem>
                      <SelectItem value="high">Élevée</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Catégorie</Label>
                  <Select value={newMemo.category} onValueChange={(value: any) => setNewMemo({...newMemo, category: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">Général</SelectItem>
                      <SelectItem value="stock">Stock</SelectItem>
                      <SelectItem value="vente">Vente</SelectItem>
                      <SelectItem value="rappel">Rappel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button onClick={handleAddMemo} className="w-full">
                Ajouter le mémo
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {userMemos.map((memo) => (
          <Card key={memo.id} className={`hover:shadow-md transition-shadow ${memo.completed ? 'opacity-60' : ''}`}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className={`text-lg ${memo.completed ? 'line-through' : ''}`}>
                  {memo.title}
                </CardTitle>
                <div className="flex space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingMemo(memo)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteMemo(memo.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <p className={`text-sm ${memo.completed ? 'line-through' : ''}`}>
                  {memo.content}
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    <Badge variant={getPriorityColor(memo.priority)}>
                      {memo.priority === 'high' ? 'Élevée' : memo.priority === 'medium' ? 'Moyenne' : 'Faible'}
                    </Badge>
                    <Badge variant="outline">
                      {getCategoryLabel(memo.category)}
                    </Badge>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500 flex items-center">
                    <Calendar className="w-3 h-3 mr-1" />
                    {new Date(memo.createdAt).toLocaleDateString()}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleCompleted(memo.id)}
                  >
                    {memo.completed ? 'Réactiver' : 'Terminer'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {userMemos.length === 0 && (
        <div className="text-center text-gray-500 py-8">
          <StickyNote className="w-12 h-12 mx-auto mb-4 opacity-50" />
          <p>Aucun mémo enregistré</p>
        </div>
      )}

      {editingMemo && (
        <Dialog open={!!editingMemo} onOpenChange={() => setEditingMemo(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Modifier le mémo</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Titre</Label>
                <Input
                  value={editingMemo.title}
                  onChange={(e) => setEditingMemo({...editingMemo, title: e.target.value})}
                />
              </div>
              <div>
                <Label>Contenu</Label>
                <Textarea
                  value={editingMemo.content}
                  onChange={(e) => setEditingMemo({...editingMemo, content: e.target.value})}
                  rows={4}
                />
              </div>
              <Button onClick={handleUpdateMemo} className="w-full">
                Mettre à jour
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
