import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Plus, Search, Edit, Trash2, AlertTriangle } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product } from '../types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';

export function ProductsManagement() {
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [newProduct, setNewProduct] = useState({
    name: '',
    category: '',
    quantity: 0,
    purchasePrice: 0,
    salePrice: 0,
    supplier: '',
    minStock: 5
  });

  const categories = ['Ustensiles', 'Électroménager', 'Vaisselle', 'Décoration', 'Accessoires'];

  const handleAddProduct = () => {
    if (!isAdmin) {
      toast({
        title: "Accès refusé",
        description: "Seul l'administrateur peut ajouter des produits",
        variant: "destructive"
      });
      return;
    }

    const product: Product = {
      id: Date.now().toString(),
      ...newProduct,
      entryDate: new Date(),
      lastUpdated: new Date()
    };

    setProducts([...products, product]);
    setNewProduct({
      name: '',
      category: '',
      quantity: 0,
      purchasePrice: 0,
      salePrice: 0,
      supplier: '',
      minStock: 5
    });
    setIsAddDialogOpen(false);
    toast({
      title: "Produit ajouté",
      description: "Le produit a été ajouté avec succès",
    });
  };

  const handleUpdateProduct = () => {
    if (!editingProduct) return;
    
    const updatedProducts = products.map(p => 
      p.id === editingProduct.id 
        ? { ...editingProduct, lastUpdated: new Date() }
        : p
    );
    setProducts(updatedProducts);
    setEditingProduct(null);
    toast({
      title: "Produit modifié",
      description: "Le produit a été modifié avec succès",
    });
  };

  const handleDeleteProduct = (id: string) => {
    if (!isAdmin) {
      toast({
        title: "Accès refusé",
        description: "Seul l'administrateur peut supprimer des produits",
        variant: "destructive"
      });
      return;
    }

    setProducts(products.filter(p => p.id !== id));
    toast({
      title: "Produit supprimé",
      description: "Le produit a été supprimé avec succès",
    });
  };

  const canEditPrices = (field: string) => {
    return isAdmin || (field !== 'purchasePrice' && field !== 'salePrice');
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.supplier.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const lowStockProducts = products.filter(p => p.quantity <= p.minStock);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestion des Produits</h2>
        {isAdmin && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Ajouter un produit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Ajouter un nouveau produit</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Nom du produit</Label>
                  <Input
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Catégorie</Label>
                  <Select value={newProduct.category} onValueChange={(value) => setNewProduct({...newProduct, category: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner une catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Quantité</Label>
                    <Input
                      type="number"
                      value={newProduct.quantity}
                      onChange={(e) => setNewProduct({...newProduct, quantity: parseInt(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Stock minimum</Label>
                    <Input
                      type="number"
                      value={newProduct.minStock}
                      onChange={(e) => setNewProduct({...newProduct, minStock: parseInt(e.target.value) || 5})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Prix d'achat (FCFA)</Label>
                    <Input
                      type="number"
                      value={newProduct.purchasePrice}
                      onChange={(e) => setNewProduct({...newProduct, purchasePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Prix de vente (FCFA)</Label>
                    <Input
                      type="number"
                      value={newProduct.salePrice}
                      onChange={(e) => setNewProduct({...newProduct, salePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                </div>
                <div>
                  <Label>Fournisseur</Label>
                  <Input
                    value={newProduct.supplier}
                    onChange={(e) => setNewProduct({...newProduct, supplier: e.target.value})}
                  />
                </div>
                <Button onClick={handleAddProduct} className="w-full">
                  Ajouter le produit
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {lowStockProducts.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-700 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Alerte Stock Faible
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-orange-600">
              {lowStockProducts.length} produit(s) ont un stock faible
            </p>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center space-x-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Rechercher un produit..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{product.name}</CardTitle>
                <div className="flex space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingProduct(product)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Badge variant="secondary">{product.category}</Badge>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Stock: {product.quantity}</div>
                  <div>Min: {product.minStock}</div>
                  <div>Achat: {product.purchasePrice} FCFA</div>
                  <div>Vente: {product.salePrice} FCFA</div>
                </div>
                <div className="text-sm text-gray-500">
                  Fournisseur: {product.supplier}
                </div>
                {product.quantity <= product.minStock && (
                  <Badge variant="destructive" className="text-xs">
                    Stock faible
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {editingProduct && (
        <Dialog open={!!editingProduct} onOpenChange={() => setEditingProduct(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Modifier le produit</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Nom du produit</Label>
                <Input
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})}
                />
              </div>
              <div>
                <Label>Quantité</Label>
                <Input
                  type="number"
                  value={editingProduct.quantity}
                  onChange={(e) => setEditingProduct({...editingProduct, quantity: parseInt(e.target.value) || 0})}
                />
              </div>
              {isAdmin && (
                <>
                  <div>
                    <Label>Prix d'achat (FCFA)</Label>
                    <Input
                      type="number"
                      value={editingProduct.purchasePrice}
                      onChange={(e) => setEditingProduct({...editingProduct, purchasePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <Label>Prix de vente (FCFA)</Label>
                    <Input
                      type="number"
                      value={editingProduct.salePrice}
                      onChange={(e) => setEditingProduct({...editingProduct, salePrice: parseFloat(e.target.value) || 0})}
                    />
                  </div>
                </>
              )}
              {!isAdmin && (
                <div className="text-sm text-gray-500 p-2 bg-gray-50 rounded">
                  Seul l'administrateur peut modifier les prix d'achat et de vente
                </div>
              )}
              <Button onClick={handleUpdateProduct} className="w-full">
                Mettre à jour
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
