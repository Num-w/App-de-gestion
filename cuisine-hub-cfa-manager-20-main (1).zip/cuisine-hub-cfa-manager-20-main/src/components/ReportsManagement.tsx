
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { FileText, Download, TrendingUp, Package, DollarSign } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Sale, GasSale } from '../types';

export function ReportsManagement() {
  const [products] = useLocalStorage<Product[]>('products', []);
  const [sales] = useLocalStorage<Sale[]>('sales', []);
  const [gasSales] = useLocalStorage<GasSale[]>('gasSales', []);
  const [reportType, setReportType] = useState('daily');
  const [reportCategory, setReportCategory] = useState('sales');

  const getSalesData = () => {
    const today = new Date();
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.date);
      switch (reportType) {
        case 'daily':
          return saleDate.toDateString() === today.toDateString();
        case 'weekly':
          const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
          return saleDate >= weekAgo;
        case 'monthly':
          return saleDate.getMonth() === today.getMonth() && saleDate.getFullYear() === today.getFullYear();
        case 'yearly':
          return saleDate.getFullYear() === today.getFullYear();
        default:
          return true;
      }
    });

    return filteredSales.reduce((total, sale) => total + sale.total, 0);
  };

  const getProductsSold = () => {
    const today = new Date();
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.date);
      switch (reportType) {
        case 'daily':
          return saleDate.toDateString() === today.toDateString();
        case 'weekly':
          const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
          return saleDate >= weekAgo;
        case 'monthly':
          return saleDate.getMonth() === today.getMonth() && saleDate.getFullYear() === today.getFullYear();
        case 'yearly':
          return saleDate.getFullYear() === today.getFullYear();
        default:
          return true;
      }
    });

    const productSales: { [key: string]: number } = {};
    filteredSales.forEach(sale => {
      sale.products.forEach(item => {
        productSales[item.productName] = (productSales[item.productName] || 0) + item.quantity;
      });
    });

    return Object.entries(productSales).map(([name, quantity]) => ({
      name,
      quantity
    })).slice(0, 5);
  };

  const getStockData = () => {
    return products.map(product => ({
      name: product.name,
      stock: product.quantity,
      status: product.quantity <= product.minStock ? 'Faible' : 'Normal'
    }));
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Rapports et Analyses</h2>
        <div className="flex space-x-2">
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Aujourd'hui</SelectItem>
              <SelectItem value="weekly">Cette semaine</SelectItem>
              <SelectItem value="monthly">Ce mois</SelectItem>
              <SelectItem value="yearly">Cette année</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Exporter PDF
          </Button>
        </div>
      </div>

      {/* Statistiques générales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="w-8 h-8 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Ventes ({reportType})</p>
                <p className="text-2xl font-bold">{getSalesData().toLocaleString()} FCFA</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Package className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Produits en stock</p>
                <p className="text-2xl font-bold">{products.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Ventes totales</p>
                <p className="text-2xl font-bold">{sales.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="w-8 h-8 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Stock faible</p>
                <p className="text-2xl font-bold">{products.filter(p => p.quantity <= p.minStock).length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Produits les plus vendus ({reportType})</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={getProductsSold()}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="quantity" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>État du stock</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={getStockData()}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, stock }) => `${name}: ${stock}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="stock"
                >
                  {getStockData().map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Tableau détaillé des ventes */}
      <Card>
        <CardHeader>
          <CardTitle>Détail des ventes récentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {sales.slice(-10).reverse().map((sale) => (
              <div key={sale.id} className="flex justify-between items-center p-2 border rounded">
                <div>
                  <div className="font-medium">{sale.customerName}</div>
                  <div className="text-sm text-gray-500">
                    {new Date(sale.date).toLocaleDateString()} - {sale.products.length} produit(s)
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold">{sale.total} FCFA</div>
                  <div className="text-sm text-gray-500">{sale.paymentMethod === 'cash' ? 'Espèces' : 'Crédit'}</div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
