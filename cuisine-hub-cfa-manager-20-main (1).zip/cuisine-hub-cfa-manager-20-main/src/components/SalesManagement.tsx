
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ShoppingCart, Plus, Minus, Receipt, Trash2 } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Product, Sale, SaleItem } from '../types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';

export function SalesManagement() {
  const { user } = useAuth();
  const [products, setProducts] = useLocalStorage<Product[]>('products', []);
  const [sales, setSales] = useLocalStorage<Sale[]>('sales', []);
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerContact, setCustomerContact] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit'>('cash');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [saleToDelete, setSaleToDelete] = useState<Sale | null>(null);
  const { toast } = useToast();

  const addToCart = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    if (product.quantity <= 0) {
      toast({
        title: "Stock insuffisant",
        description: "Ce produit n'est plus en stock",
        variant: "destructive"
      });
      return;
    }

    const existingItem = cart.find(item => item.productId === productId);
    
    if (existingItem) {
      if (existingItem.quantity >= product.quantity) {
        toast({
          title: "Stock insuffisant",
          description: "Impossible d'ajouter plus d'unités",
          variant: "destructive"
        });
        return;
      }
      setCart(cart.map(item =>
        item.productId === productId
          ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.unitPrice }
          : item
      ));
    } else {
      const newItem: SaleItem = {
        productId: product.id,
        productName: product.name,
        quantity: 1,
        unitPrice: product.salePrice,
        subtotal: product.salePrice
      };
      setCart([...cart, newItem]);
    }
  };

  const updateCartQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      setCart(cart.filter(item => item.productId !== productId));
      return;
    }

    const product = products.find(p => p.id === productId);
    if (!product || newQuantity > product.quantity) {
      toast({
        title: "Stock insuffisant",
        description: "Quantité demandée supérieure au stock disponible",
        variant: "destructive"
      });
      return;
    }

    setCart(cart.map(item =>
      item.productId === productId
        ? { ...item, quantity: newQuantity, subtotal: newQuantity * item.unitPrice }
        : item
    ));
  };

  const getTotalAmount = () => {
    return cart.reduce((total, item) => total + item.subtotal, 0);
  };

  const completeSale = () => {
    if (cart.length === 0) {
      toast({
        title: "Panier vide",
        description: "Ajoutez des produits avant de finaliser la vente",
        variant: "destructive"
      });
      return;
    }

    // Créer la vente
    const sale: Sale = {
      id: Date.now().toString(),
      products: cart,
      customerName: customerName || 'Client anonyme',
      customerContact: customerContact || '',
      total: getTotalAmount(),
      date: new Date(),
      paymentMethod
    };

    // Mettre à jour le stock des produits
    const updatedProducts = products.map(product => {
      const cartItem = cart.find(item => item.productId === product.id);
      if (cartItem) {
        return {
          ...product,
          quantity: product.quantity - cartItem.quantity,
          lastUpdated: new Date()
        };
      }
      return product;
    });

    setSales([...sales, sale]);
    setProducts(updatedProducts);
    
    // Réinitialiser le formulaire
    setCart([]);
    setCustomerName('');
    setCustomerContact('');
    setPaymentMethod('cash');

    toast({
      title: "Vente enregistrée",
      description: `Vente de ${getTotalAmount()} FCFA enregistrée avec succès`,
    });
  };

  const handleDeleteSale = () => {
    if (!saleToDelete) return;

    // Remettre les produits en stock
    const updatedProducts = products.map(product => {
      const saleItem = saleToDelete.products.find(item => item.productId === product.id);
      if (saleItem) {
        return {
          ...product,
          quantity: product.quantity + saleItem.quantity,
          lastUpdated: new Date()
        };
      }
      return product;
    });

    // Supprimer la vente
    setSales(sales.filter(s => s.id !== saleToDelete.id));
    setProducts(updatedProducts);
    
    setDeleteDialogOpen(false);
    setSaleToDelete(null);

    toast({
      title: "Vente supprimée",
      description: "La vente a été supprimée et le stock a été restauré",
    });
  };

  const availableProducts = products.filter(p => p.quantity > 0);
  const isAdmin = user?.role === 'admin';

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Gestion des Ventes</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sélection de produits */}
        <Card>
          <CardHeader>
            <CardTitle>Ajouter des produits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Label>Sélectionner un produit</Label>
              <Select onValueChange={addToCart}>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un produit..." />
                </SelectTrigger>
                <SelectContent>
                  {availableProducts.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name} - {product.salePrice} FCFA (Stock: {product.quantity})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Panier */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <ShoppingCart className="w-5 h-5 mr-2" />
              Panier ({cart.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {cart.map((item) => (
                <div key={item.productId} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex-1">
                    <div className="font-medium">{item.productName}</div>
                    <div className="text-sm text-gray-500">{item.unitPrice} FCFA/unité</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateCartQuantity(item.productId, item.quantity - 1)}
                    >
                      <Minus className="w-3 h-3" />
                    </Button>
                    <span className="w-8 text-center">{item.quantity}</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateCartQuantity(item.productId, item.quantity + 1)}
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                    <div className="w-20 text-right font-medium">
                      {item.subtotal} FCFA
                    </div>
                  </div>
                </div>
              ))}
              {cart.length === 0 && (
                <div className="text-center text-gray-500 py-4">
                  Panier vide
                </div>
              )}
            </div>
            {cart.length > 0 && (
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between items-center font-bold text-lg">
                  <span>Total:</span>
                  <span>{getTotalAmount()} FCFA</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Informations client et finalisation */}
      <Card>
        <CardHeader>
          <CardTitle>Finaliser la vente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Nom du client (optionnel)</Label>
              <Input
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Nom du client"
              />
            </div>
            <div>
              <Label>Contact (optionnel)</Label>
              <Input
                value={customerContact}
                onChange={(e) => setCustomerContact(e.target.value)}
                placeholder="Téléphone/Email"
              />
            </div>
            <div>
              <Label>Mode de paiement</Label>
              <Select value={paymentMethod} onValueChange={(value: 'cash' | 'credit') => setPaymentMethod(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Espèces</SelectItem>
                  <SelectItem value="credit">Crédit</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <Button onClick={completeSale} className="w-full" disabled={cart.length === 0}>
              <Receipt className="w-4 h-4 mr-2" />
              Finaliser la vente - {getTotalAmount()} FCFA
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Historique des ventes récentes */}
      <Card>
        <CardHeader>
          <CardTitle>Ventes récentes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {sales.slice(-5).reverse().map((sale) => (
              <div key={sale.id} className="flex justify-between items-center p-2 border rounded">
                <div>
                  <div className="font-medium">{sale.customerName}</div>
                  <div className="text-sm text-gray-500">
                    {new Date(sale.date).toLocaleDateString()} - {sale.products.length} produit(s)
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="text-right">
                    <div className="font-bold">{sale.total} FCFA</div>
                    <div className="text-sm text-gray-500">{sale.paymentMethod === 'cash' ? 'Espèces' : 'Crédit'}</div>
                  </div>
                  {isAdmin && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSaleToDelete(sale);
                        setDeleteDialogOpen(true);
                      }}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            {sales.length === 0 && (
              <div className="text-center text-gray-500 py-4">
                Aucune vente enregistrée
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Dialog de confirmation de suppression */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer cette vente ? Cette action restaurera automatiquement le stock des produits.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Annuler
            </Button>
            <Button variant="destructive" onClick={handleDeleteSale}>
              Supprimer
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
