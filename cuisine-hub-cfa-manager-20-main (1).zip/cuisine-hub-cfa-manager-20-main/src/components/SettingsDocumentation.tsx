
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Info, CheckCircle, Settings } from 'lucide-react';

export function SettingsDocumentation() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-4">Documentation des Paramètres</h2>
        <p className="text-gray-600 mb-6">
          Guide d'utilisation des fonctionnalités avancées - Version 3.2
        </p>
      </div>

      {/* Mise à jour automatique */}
      <Card className="settings-section">
        <CardHeader>
          <CardTitle className="flex items-center">
            <CheckCircle className="mr-2 h-5 w-5 text-green-500" />
            Mise à jour automatique
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Comment ça fonctionne :</h4>
            <ul className="list-disc pl-5 space-y-2">
              <li>Vérification automatique des nouvelles versions au démarrage</li>
              <li>Téléchargement en arrière-plan des mises à jour disponibles</li>
              <li>Installation programmée pendant les heures de faible activité</li>
              <li>Sauvegarde automatique avant chaque mise à jour</li>
            </ul>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border p-3 rounded">
              <h5 className="font-medium text-green-600">Avantages</h5>
              <ul className="text-sm mt-2 space-y-1">
                <li>• Sécurité renforcée</li>
                <li>• Nouvelles fonctionnalités</li>
                <li>• Corrections de bugs</li>
                <li>• Performance améliorée</li>
              </ul>
            </div>
            <div className="border p-3 rounded">
              <h5 className="font-medium text-orange-600">Configuration</h5>
              <ul className="text-sm mt-2 space-y-1">
                <li>• Fréquence de vérification</li>
                <li>• Heures d'installation</li>
                <li>• Notifications</li>
                <li>• Mode de sauvegarde</li>
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
            <div className="flex">
              <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2" />
              <div>
                <p className="font-medium">Important :</p>
                <p className="text-sm">Une connexion internet stable est requise. Les mises à jour critiques de sécurité s'installent automatiquement.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mode maintenance */}
      <Card className="settings-section">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Settings className="mr-2 h-5 w-5 text-orange-500" />
            Mode maintenance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-orange-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Comment ça fonctionne :</h4>
            <ul className="list-disc pl-5 space-y-2">
              <li>Active un mode de protection de l'application</li>
              <li>Bloque l'accès aux utilisateurs non-administrateurs</li>
              <li>Permet les opérations de maintenance en sécurité</li>
              <li>Affiche un message personnalisable aux utilisateurs</li>
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border p-3 rounded">
              <h5 className="font-medium text-blue-600">Utilisation</h5>
              <ul className="text-sm mt-2 space-y-1">
                <li>• Sauvegarde de données</li>
                <li>• Réparation de base</li>
                <li>• Migration système</li>
                <li>• Tests de sécurité</li>
              </ul>
            </div>
            <div className="border p-3 rounded">
              <h5 className="font-medium text-green-600">Protection</h5>
              <ul className="text-sm mt-2 space-y-1">
                <li>• Données protégées</li>
                <li>• Accès limité</li>
                <li>• Intégrité préservée</li>
                <li>• Logs détaillés</li>
              </ul>
            </div>
            <div className="border p-3 rounded">
              <h5 className="font-medium text-purple-600">Options</h5>
              <ul className="text-sm mt-2 space-y-1">
                <li>• Durée programmée</li>
                <li>• Message personnalisé</li>
                <li>• Accès admin</li>
                <li>• Mode d'urgence</li>
              </ul>
            </div>
          </div>

          <div className="bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <Info className="h-5 w-5 text-red-400 mr-2" />
              <div>
                <p className="font-medium">Attention :</p>
                <p className="text-sm">En mode maintenance, seuls les administrateurs peuvent accéder à l'application. Planifiez avec vos équipes.</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Synchronisation Google Drive */}
      <Card className="settings-section">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Info className="mr-2 h-5 w-5 text-blue-500" />
            Synchronisation Google Drive
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Problème d'authentification :</h4>
            <p className="text-sm">
              Si la page d'authentification Google ne s'affiche pas, cela peut être dû à :
            </p>
            <ul className="list-disc pl-5 mt-2 space-y-1 text-sm">
              <li>Bloqueur de pop-ups activé dans votre navigateur</li>
              <li>Restrictions de sécurité sur votre réseau</li>
              <li>Configuration firewall trop restrictive</li>
              <li>Version du navigateur non compatible</li>
            </ul>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Solutions recommandées :</h4>
            <ol className="list-decimal pl-5 space-y-1 text-sm">
              <li>Désactivez temporairement le bloqueur de pop-ups</li>
              <li>Ajoutez le domaine de l'application aux sites de confiance</li>
              <li>Utilisez Chrome ou Firefox en version récente</li>
              <li>Vérifiez la connexion internet</li>
              <li>Contactez votre administrateur réseau si nécessaire</li>
            </ol>
          </div>

          <Badge variant="outline" className="text-sm">
            💡 Astuce : La synchronisation fonctionne mieux avec une connexion stable et un navigateur à jour
          </Badge>
        </CardContent>
      </Card>
    </div>
  );
}
