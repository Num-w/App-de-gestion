
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings, 
  Palette, 
  Database, 
  Cloud, 
  Image, 
  Bell, 
  Shield,
  Wifi,
  WifiOff,
  Upload,
  Download,
  TestTube,
  RefreshCw,
  Users,
  Smartphone,
  Eye,
  EyeOff,
  Copy,
  AlertTriangle
} from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { StoreSettings, ThemeConfig } from '../types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';
import { useTheme, getAllBlueThemes } from '../contexts/ThemeContext';

export function SettingsManagement() {
  const { user } = useAuth();
  const { theme, setTheme, blueTheme, setBlueTheme } = useTheme();
  const blueThemes = getAllBlueThemes();
  
  const [settings, setSettings] = useLocalStorage<StoreSettings>('kitchen-store-settings', {
    name: 'Cuisine Hub',
    contact: '+237 6XX XXX XXX',
    address: 'Douala, Cameroun',
    currency: 'XAF',
    taxRate: 0
  });
  
  const [originalSettings, setOriginalSettings] = useState(settings);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  const [wampConfig, setWampConfig] = useLocalStorage('wamp-config', {
    server: 'localhost',
    port: '3306',
    database: '',
    username: '',
    password: '',
    connected: false
  });
  
  const [driveConfig, setDriveConfig] = useLocalStorage('drive-config', {
    connected: false,
    folder: '',
    autoSync: 'manual',
    lastSync: null
  });

  const [hotspotConfig, setHotspotConfig] = useLocalStorage('hotspot-config', {
    ssid: 'GasManager-Hotspot',
    password: '',
    serverIP: '192.168.137.1',
    serverPort: '8080',
    isActive: false
  });

  // Nouveaux états pour gestion utilisateurs
  const [users, setUsers] = useLocalStorage('app-users', [
    {
      id: '1',
      username: 'admin',
      email: 'admin@example.com',
      firstName: 'Admin',
      lastName: 'User',
      role: 'admin',
      isActive: true,
      lastLogin: new Date().toISOString(),
      createdAt: new Date().toISOString()
    }
  ]);

  const [activeSessions, setActiveSessions] = useLocalStorage('active-sessions', []);
  const [activityLogs, setActivityLogs] = useLocalStorage('activity-logs', []);
  
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const { toast } = useToast();
  
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    // Détecter les changements
    const hasChanges = JSON.stringify(settings) !== JSON.stringify(originalSettings);
    setHasUnsavedChanges(hasChanges);
  }, [settings, originalSettings]);

  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    if (!isAdmin && (newSettings.name || newSettings.contact || newSettings.address)) {
      toast({
        title: "Accès refusé",
        description: "Seuls les administrateurs peuvent modifier ces paramètres",
        variant: "destructive"
      });
      return;
    }
    
    setSettings({ ...settings, ...newSettings });
  };

  const applyChanges = () => {
    setOriginalSettings(settings);
    setHasUnsavedChanges(false);
    toast({
      title: "Paramètres appliqués",
      description: "Les modifications ont été appliquées avec succès",
    });
  };

  const confirmChanges = () => {
    applyChanges();
    toast({
      title: "Paramètres sauvegardés",
      description: "Toutes les modifications ont été sauvegardées",
    });
  };

  const cancelChanges = () => {
    if (hasUnsavedChanges) {
      const confirmed = window.confirm("Annuler les modifications non sauvegardées ?");
      if (confirmed) {
        setSettings(originalSettings);
        setHasUnsavedChanges(false);
      }
    }
  };

  const refreshData = () => {
    // Recharger les données depuis localStorage
    const freshSettings = JSON.parse(localStorage.getItem('kitchen-store-settings') || '{}');
    setSettings({ ...settings, ...freshSettings });
    setOriginalSettings({ ...settings, ...freshSettings });
    setHasUnsavedChanges(false);
    
    toast({
      title: "Données actualisées",
      description: "Les paramètres ont été rechargés",
    });
  };

  const generatePassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setHotspotConfig({ ...hotspotConfig, password });
  };

  const toggleHotspot = () => {
    if (hotspotConfig.isActive) {
      setHotspotConfig({ ...hotspotConfig, isActive: false });
      toast({
        title: "Hotspot arrêté",
        description: "Le point d'accès WiFi a été désactivé",
      });
    } else {
      if (!hotspotConfig.password) {
        toast({
          title: "Mot de passe requis",
          description: "Veuillez définir un mot de passe pour le hotspot",
          variant: "destructive"
        });
        return;
      }
      
      setHotspotConfig({ ...hotspotConfig, isActive: true });
      toast({
        title: "Hotspot démarré",
        description: "Le point d'accès WiFi a été activé avec succès",
      });
    }
  };

  const copyToClipboard = (text: string, message: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié !",
      description: message,
    });
  };

  const testWampConnection = async () => {
    toast({
      title: "Test de connexion",
      description: "Tentative de connexion au serveur WAMP...",
    });
    
    setTimeout(() => {
      const success = Math.random() > 0.5;
      if (success) {
        setWampConfig({ ...wampConfig, connected: true });
        toast({
          title: "Connexion réussie",
          description: "Connexion établie avec le serveur WAMP",
        });
      } else {
        toast({
          title: "Échec de la connexion",
          description: "Impossible de se connecter au serveur WAMP",
          variant: "destructive"
        });
      }
    }, 2000);
  };

  const syncToWamp = () => {
    if (!wampConfig.connected) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord établir la connexion WAMP",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Synchronisation en cours",
      description: "Synchronisation des données vers le serveur WAMP...",
    });
  };

  const connectGoogleDrive = () => {
    toast({
      title: "Connexion Google Drive",
      description: "Redirection vers l'authentification Google...",
    });
  };

  const syncToDrive = () => {
    if (!driveConfig.connected) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord connecter Google Drive",
        variant: "destructive"
      });
      return;
    }
    
    setDriveConfig({ ...driveConfig, lastSync: new Date().toISOString() });
    toast({
      title: "Synchronisation réussie",
      description: "Données sauvegardées sur Google Drive",
    });
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast({
          title: "Fichier trop volumineux",
          description: "Le logo ne doit pas dépasser 2MB",
          variant: "destructive"
        });
        return;
      }
      
      setLogoFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        updateSettings({ logo: e.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  // Fonctions pour gestion utilisateurs
  const createUser = (userData: any) => {
    const newUser = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      lastLogin: null
    };
    setUsers([...users, newUser]);
    toast({
      title: "Utilisateur créé",
      description: `L'utilisateur ${userData.username} a été créé avec succès`,
    });
  };

  const updateUser = (userId: string, userData: any) => {
    setUsers(users.map(u => u.id === userId ? { ...u, ...userData } : u));
    toast({
      title: "Utilisateur modifié",
      description: "Les informations de l'utilisateur ont été mises à jour",
    });
  };

  const deleteUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user?.role === 'admin' && users.filter(u => u.role === 'admin').length === 1) {
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le dernier administrateur",
        variant: "destructive"
      });
      return;
    }
    
    setUsers(users.filter(u => u.id !== userId));
    toast({
      title: "Utilisateur supprimé",
      description: "L'utilisateur a été supprimé avec succès",
    });
  };

  const [activeTab, setActiveTab] = useState('general');
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Paramètres</h2>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={refreshData}
          >
            <RefreshCw className="mr-2 h-4 w-4" /> 
            Actualiser
          </Button>
        </div>
      </div>

      <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4 w-full flex flex-wrap">
          <TabsTrigger value="general" className="flex-1">
            <Settings className="w-4 h-4 mr-2" /> Général
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex-1">
            <Palette className="w-4 h-4 mr-2" /> Apparence
          </TabsTrigger>
          {isAdmin && (
            <>
              <TabsTrigger value="sync" className="flex-1">
                <Database className="w-4 h-4 mr-2" /> Synchronisation
              </TabsTrigger>
              <TabsTrigger value="mobile" className="flex-1">
                <Smartphone className="w-4 h-4 mr-2" /> Connect Mobile
              </TabsTrigger>
              <TabsTrigger value="users" className="flex-1">
                <Users className="w-4 h-4 mr-2" /> Utilisateurs
              </TabsTrigger>
              <TabsTrigger value="security" className="flex-1">
                <Shield className="w-4 h-4 mr-2" /> Sécurité
              </TabsTrigger>
            </>
          )}
        </TabsList>

        {/* Onglet Général */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2" />
                Informations de la boutique
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Nom de la boutique</Label>
                  <Input
                    value={settings.name}
                    onChange={(e) => updateSettings({ name: e.target.value })}
                    disabled={!isAdmin}
                    className={!isAdmin ? "bg-gray-100" : ""}
                  />
                  {!isAdmin && <p className="text-xs text-gray-500 mt-1">Réservé aux administrateurs</p>}
                </div>
                <div>
                  <Label>Contact</Label>
                  <Input
                    value={settings.contact}
                    onChange={(e) => updateSettings({ contact: e.target.value })}
                    disabled={!isAdmin}
                    className={!isAdmin ? "bg-gray-100" : ""}
                  />
                </div>
                <div>
                  <Label>Adresse</Label>
                  <Input
                    value={settings.address}
                    onChange={(e) => updateSettings({ address: e.target.value })}
                    disabled={!isAdmin}
                    className={!isAdmin ? "bg-gray-100" : ""}
                  />
                </div>
                <div>
                  <Label>Devise</Label>
                  <Select value={settings.currency} onValueChange={(value) => updateSettings({ currency: value })}>
                    <SelectTrigger disabled={!isAdmin}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="XAF">XAF (Franc CFA)</SelectItem>
                      <SelectItem value="EUR">EUR (Euro)</SelectItem>
                      <SelectItem value="USD">USD (Dollar)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Taux de TVA (%)</Label>
                  <Input
                    type="number"
                    value={settings.taxRate}
                    onChange={(e) => updateSettings({ taxRate: Number(e.target.value) })}
                    disabled={!isAdmin}
                    className={!isAdmin ? "bg-gray-100" : ""}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Notifications et Alertes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Alertes de stock minimum</Label>
                  <p className="text-sm text-gray-500">Recevoir des notifications quand le stock est faible</p>
                </div>
                <Switch />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label>Récapitulatif quotidien des ventes</Label>
                  <p className="text-sm text-gray-500">Email de résumé des ventes journalières</p>
                </div>
                <Switch disabled={!isAdmin} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <Label>Alertes de sécurité</Label>
                  <p className="text-sm text-gray-500">Notifications pour les nouvelles connexions</p>
                </div>
                <Switch disabled={!isAdmin} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Onglet Apparence */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Palette className="w-5 h-5 mr-2" />
                Thème et Apparence
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>Thème principal</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div 
                    className={`p-4 border rounded-lg cursor-pointer transition-all hover:bg-gray-50 ${theme === 'light' ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setTheme('light')}
                  >
                    <div className="h-20 bg-[#f8fafc] rounded-md border border-gray-200 mb-2"></div>
                    <div className="text-center">Clair</div>
                  </div>
                  <div 
                    className={`p-4 border rounded-lg cursor-pointer transition-all hover:bg-gray-50 ${theme === 'dark' ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setTheme('dark')}
                  >
                    <div className="h-20 bg-[#0f172a] rounded-md border border-gray-700 mb-2"></div>
                    <div className="text-center">Sombre</div>
                  </div>
                  <div 
                    className={`p-4 border rounded-lg cursor-pointer transition-all hover:bg-gray-50 ${theme === 'system' ? 'ring-2 ring-primary' : ''}`}
                    onClick={() => setTheme('system')}
                  >
                    <div className="h-20 bg-gradient-to-r from-[#f8fafc] to-[#0f172a] rounded-md border mb-2"></div>
                    <div className="text-center">Système</div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <Label>Thèmes bleus</Label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {blueThemes.map((blueThemeItem) => (
                    <div 
                      key={blueThemeItem.name} 
                      className={`p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-colors ${blueTheme === blueThemeItem.name ? 'ring-2 ring-primary' : ''}`}
                      onClick={() => setBlueTheme(blueTheme === blueThemeItem.name ? null : blueThemeItem.name)}
                    >
                      <div className="h-24 rounded-md mb-2 overflow-hidden">
                        <div className="h-1/3 w-full" style={{backgroundColor: blueThemeItem.primary}}></div>
                        <div className="h-1/3 w-full" style={{backgroundColor: blueThemeItem.secondary}}></div>
                        <div className="h-1/3 w-full" style={{backgroundColor: blueThemeItem.accent}}></div>
                      </div>
                      <div className="text-center">{blueThemeItem.name}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Gestion du logo (Admin uniquement) */}
          {isAdmin && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Image className="w-5 h-5 mr-2" />
                  Gestion du logo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {settings.logo && (
                  <div>
                    <Label>Logo actuel</Label>
                    <div className="mt-2 p-4 border rounded-lg bg-gray-50">
                      <img src={settings.logo} alt="Logo" className="max-h-20 max-w-40 object-contain" />
                    </div>
                  </div>
                )}
                <div>
                  <Label>Changer le logo</Label>
                  <Input
                    type="file"
                    accept="image/jpeg,image/png,image/svg+xml"
                    onChange={handleLogoUpload}
                    className="mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Formats acceptés : JPG, PNG, SVG (max 2MB) - Dimensions recommandées : 200x80px
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Onglet Synchronisation */}
        {isAdmin && (
          <TabsContent value="sync" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="w-5 h-5 mr-2" />
                  Synchronisation Serveur Local (WAMP)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <span>Statut :</span>
                  {wampConfig.connected ? (
                    <Badge className="bg-green-100 text-green-800">
                      <Wifi className="w-3 h-3 mr-1" />
                      Connecté
                    </Badge>
                  ) : (
                    <Badge className="bg-red-100 text-red-800">
                      <WifiOff className="w-3 h-3 mr-1" />
                      Déconnecté
                    </Badge>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Adresse serveur</Label>
                    <Input
                      value={wampConfig.server}
                      onChange={(e) => setWampConfig({ ...wampConfig, server: e.target.value })}
                      placeholder="localhost ou 192.168.1.100"
                    />
                  </div>
                  <div>
                    <Label>Port</Label>
                    <Input
                      value={wampConfig.port}
                      onChange={(e) => setWampConfig({ ...wampConfig, port: e.target.value })}
                      placeholder="3306"
                    />
                  </div>
                  <div>
                    <Label>Nom de la base de données</Label>
                    <Input
                      value={wampConfig.database}
                      onChange={(e) => setWampConfig({ ...wampConfig, database: e.target.value })}
                      placeholder="cuisine_hub_db"
                    />
                  </div>
                  <div>
                    <Label>Utilisateur</Label>
                    <Input
                      value={wampConfig.username}
                      onChange={(e) => setWampConfig({ ...wampConfig, username: e.target.value })}
                      placeholder="root"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label>Mot de passe</Label>
                    <Input
                      type="password"
                      value={wampConfig.password}
                      onChange={(e) => setWampConfig({ ...wampConfig, password: e.target.value })}
                      placeholder="••••••••"
                    />
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={testWampConnection} variant="outline">
                    <TestTube className="w-4 h-4 mr-2" />
                    Tester la connexion
                  </Button>
                  <Button onClick={syncToWamp} disabled={!wampConfig.connected}>
                    <Upload className="w-4 h-4 mr-2" />
                    Synchroniser maintenant
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Cloud className="w-5 h-5 mr-2" />
                  Synchronisation Cloud (Google Drive)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <span>Compte Google :</span>
                  {driveConfig.connected ? (
                    <Badge className="bg-green-100 text-green-800">Connecté</Badge>
                  ) : (
                    <Badge className="bg-gray-100 text-gray-800">Non connecté</Badge>
                  )}
                </div>
                
                {!driveConfig.connected ? (
                  <Button onClick={connectGoogleDrive}>
                    Connecter avec Google
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <Label>Dossier de sauvegarde</Label>
                      <Input
                        value={driveConfig.folder}
                        onChange={(e) => setDriveConfig({ ...driveConfig, folder: e.target.value })}
                        placeholder="CuisineHub_Backup"
                      />
                    </div>
                    <div>
                      <Label>Fréquence de synchronisation automatique</Label>
                      <Select 
                        value={driveConfig.autoSync} 
                        onValueChange={(value) => setDriveConfig({ ...driveConfig, autoSync: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="manual">Manuel</SelectItem>
                          <SelectItem value="daily">Quotidien</SelectItem>
                          <SelectItem value="weekly">Hebdomadaire</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {driveConfig.lastSync && (
                      <div>
                        <Label>Dernière synchronisation</Label>
                        <p className="text-sm text-gray-600">
                          {new Date(driveConfig.lastSync).toLocaleString('fr-FR')}
                        </p>
                      </div>
                    )}
                    <div className="flex space-x-2">
                      <Button onClick={syncToDrive}>
                        <Upload className="w-4 h-4 mr-2" />
                        Synchroniser vers Drive
                      </Button>
                      <Button variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Restaurer depuis Drive
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Onglet Connect Mobile */}
        {isAdmin && (
          <TabsContent value="mobile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Smartphone className="w-5 h-5 mr-2" />
                  Connexion Mobile
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-sm text-gray-600 mb-4">
                  Activez le hotspot WiFi pour connecter votre mobile/tablette directement
                  à l'ordinateur sans passer par le routeur principal.
                </div>
                
                <div className="flex justify-center mb-6">
                  <div className="flex items-center bg-gray-100 rounded-full px-6 py-3">
                    <span className={`h-3 w-3 rounded-full mr-2 ${hotspotConfig.isActive ? 'bg-green-500' : 'bg-red-500'}`}></span>
                    <span className="font-medium">{hotspotConfig.isActive ? 'Hotspot Actif' : 'Hotspot Désactivé'}</span>
                  </div>
                </div>
                
                <div className="space-y-4 border rounded-lg p-4 bg-gray-50">
                  <h3 className="text-lg font-medium">Configuration du Hotspot</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nom du Réseau (SSID)</Label>
                      <Input
                        value={hotspotConfig.ssid}
                        onChange={(e) => setHotspotConfig({ ...hotspotConfig, ssid: e.target.value })}
                        disabled={hotspotConfig.isActive}
                      />
                    </div>
                    <div>
                      <Label>Mot de Passe</Label>
                      <div className="relative">
                        <Input
                          type={showPassword ? "text" : "password"}
                          value={hotspotConfig.password}
                          onChange={(e) => setHotspotConfig({ ...hotspotConfig, password: e.target.value })}
                          disabled={hotspotConfig.isActive}
                          className="pr-20"
                        />
                        <div className="absolute right-0 top-0 h-full flex items-center pr-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="h-7 px-1"
                          >
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            type="button"
                            onClick={generatePassword}
                            className="h-7 px-1"
                            disabled={hotspotConfig.isActive}
                          >
                            🎲
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div>
                      <Label>Adresse IP Serveur</Label>
                      <Input
                        value={hotspotConfig.serverIP}
                        disabled
                        className="bg-gray-100"
                      />
                    </div>
                    <div>
                      <Label>Port d'Écoute</Label>
                      <Input
                        type="number"
                        value={hotspotConfig.serverPort}
                        onChange={(e) => setHotspotConfig({ ...hotspotConfig, serverPort: e.target.value })}
                        disabled={hotspotConfig.isActive}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-center mt-4">
                  <Button 
                    onClick={toggleHotspot} 
                    className={hotspotConfig.isActive ? "bg-red-600 hover:bg-red-700" : ""}
                    size="lg"
                  >
                    {hotspotConfig.isActive ? (
                      <>
                        <WifiOff className="mr-2 h-5 w-5" /> Arrêter le Hotspot
                      </>
                    ) : (
                      <>
                        <Wifi className="mr-2 h-5 w-5" /> Démarrer le Hotspot
                      </>
                    )}
                  </Button>
                </div>
                
                {hotspotConfig.isActive && (
                  <>
                    <div className="border rounded-lg p-6 bg-blue-50 border-blue-200 mt-6 space-y-4">
                      <h3 className="text-lg font-medium text-blue-800">Informations de Connexion</h3>
                      
                      <div className="flex flex-col md:flex-row gap-6 items-center">
                        <div className="bg-white p-4 rounded-lg border flex-shrink-0">
                          <div className="h-48 w-48 bg-gray-200 flex items-center justify-center">
                            <span className="text-sm text-gray-600">QR Code</span>
                          </div>
                        </div>
                        
                        <div className="flex-grow space-y-4 w-full">
                          <div className="flex items-center justify-between bg-white p-3 rounded border">
                            <div className="font-medium">Réseau WiFi:</div>
                            <div className="flex items-center">
                              <span className="mr-2">{hotspotConfig.ssid}</span>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(hotspotConfig.ssid, "SSID copié")}
                              >
                                <Copy size={16} />
                              </Button>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between bg-white p-3 rounded border">
                            <div className="font-medium">Mot de passe:</div>
                            <div className="flex items-center">
                              <span className="mr-2">{showPassword ? hotspotConfig.password : "••••••••"}</span>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(hotspotConfig.password, "Mot de passe copié")}
                              >
                                <Copy size={16} />
                              </Button>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between bg-white p-3 rounded border">
                            <div className="font-medium">URL Application:</div>
                            <div className="flex items-center">
                              <span className="mr-2">{`http://${hotspotConfig.serverIP}:${hotspotConfig.serverPort}`}</span>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => copyToClipboard(
                                  `http://${hotspotConfig.serverIP}:${hotspotConfig.serverPort}`,
                                  "URL copiée"
                                )}
                              >
                                <Copy size={16} />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4 bg-gray-50">
                      <h3 className="text-lg font-medium mb-2">Appareils Connectés</h3>
                      <div className="h-12 flex items-center justify-center text-gray-500 text-sm">
                        Aucun appareil connecté pour le moment
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Onglet Utilisateurs */}
        {isAdmin && (
          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  Gestion des Utilisateurs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                    <div className="text-3xl font-bold text-blue-600">{users.length}</div>
                    <div className="text-sm text-gray-600">Total Utilisateurs</div>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg border border-green-100">
                    <div className="text-3xl font-bold text-green-600">{users.filter(u => u.isActive).length}</div>
                    <div className="text-sm text-gray-600">Utilisateurs Actifs</div>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-lg border border-amber-100">
                    <div className="text-3xl font-bold text-amber-600">1</div>
                    <div className="text-sm text-gray-600">En ligne</div>
                  </div>
                </div>
                
                <div className="mb-4 flex justify-between">
                  <Button size="sm" onClick={() => setShowUserModal(true)}>
                    <span className="mr-1">+</span> Nouvel Utilisateur
                  </Button>
                  <Button variant="outline" size="sm">
                    Exporter Liste
                  </Button>
                </div>
                
                <div className="rounded-md border overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left">Utilisateur</th>
                        <th className="px-4 py-2 text-left">Rôle</th>
                        <th className="px-4 py-2 text-left">Email</th>
                        <th className="px-4 py-2 text-left">Statut</th>
                        <th className="px-4 py-2 text-left">Dernière connexion</th>
                        <th className="px-4 py-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {users.map((user) => (
                        <tr key={user.id}>
                          <td className="px-4 py-3">
                            <div className="flex items-center">
                              <div className="h-8 w-8 rounded-full bg-gray-200 mr-3"></div>
                              <div>{user.username}</div>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`text-xs font-medium px-2 py-1 rounded ${
                              user.role === 'admin' ? 'bg-red-100 text-red-800' : 
                              user.role === 'manager' ? 'bg-blue-100 text-blue-800' :
                              user.role === 'seller' ? 'bg-green-100 text-green-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {user.role === 'admin' ? 'Admin' :
                               user.role === 'manager' ? 'Gestionnaire' :
                               user.role === 'seller' ? 'Vendeur' : 'Observateur'}
                            </span>
                          </td>
                          <td className="px-4 py-3">{user.email}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2 py-1 rounded ${
                              user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {user.isActive ? 'Actif' : 'Inactif'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('fr-FR') : 'Jamais'}
                          </td>
                          <td className="px-4 py-3 text-right space-x-1">
                            <Button variant="ghost" size="sm" onClick={() => {setEditingUser(user); setShowUserModal(true)}}>✏️</Button>
                            <Button variant="ghost" size="sm">🔑</Button>
                            {user.role !== 'admin' && (
                              <Button variant="ghost" size="sm" onClick={() => deleteUser(user.id)}>🗑️</Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="text-sm text-gray-500 mt-4">
                  Cette fonctionnalité sera pleinement implémentée avec une base de données utilisateur.
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {/* Onglet Sécurité */}
        {isAdmin && (
          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Sécurité et Maintenance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Nettoyage automatique des logs</Label>
                    <p className="text-sm text-gray-500">Supprimer automatiquement les anciens logs</p>
                  </div>
                  <Select defaultValue="monthly">
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Hebdomadaire</SelectItem>
                      <SelectItem value="monthly">Mensuel</SelectItem>
                      <SelectItem value="never">Jamais</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Mise à jour automatique</Label>
                    <p className="text-sm text-gray-500">Installer automatiquement les mises à jour</p>
                  </div>
                  <Switch />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Mode maintenance</Label>
                    <p className="text-sm text-gray-500">Activer temporairement le mode maintenance</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      {/* Boutons de validation */}
      {hasUnsavedChanges && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md py-3 px-6 flex justify-between items-center z-10 dark:bg-gray-800 dark:border-gray-700">
          <div className="flex items-center">
            <AlertTriangle className="text-amber-500 mr-2 h-5 w-5" />
            <span className="text-sm font-medium text-amber-500">Modifications non sauvegardées</span>
          </div>
          <div className="space-x-2">
            <Button variant="outline" onClick={cancelChanges}>
              Annuler
            </Button>
            <Button variant="secondary" onClick={applyChanges}>
              Appliquer
            </Button>
            <Button onClick={confirmChanges}>
              OK
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
