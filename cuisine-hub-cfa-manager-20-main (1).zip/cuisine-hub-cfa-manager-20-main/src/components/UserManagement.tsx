import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Trash2, Plus, Edit, UserCheck, UserX, Key, Shield, Settings } from 'lucide-react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { User } from '../types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '../contexts/AuthContext';

interface Permission {
  id: string;
  name: string;
  description: string;
  module: string;
}

const defaultPermissions: Permission[] = [
  { id: 'view_dashboard', name: 'Voir tableau de bord', description: 'Accès au tableau de bord', module: 'dashboard' },
  { id: 'manage_products', name: 'Gérer produits', description: 'Ajouter, modifier, supprimer des produits', module: 'products' },
  { id: 'view_products', name: 'Voir produits', description: 'Consulter la liste des produits', module: 'products' },
  { id: 'manage_sales', name: 'Gérer ventes', description: 'Enregistrer et gérer les ventes', module: 'sales' },
  { id: 'view_sales', name: 'Voir ventes', description: 'Consulter les ventes', module: 'sales' },
  { id: 'manage_gas', name: 'Gérer gaz', description: 'Gestion complète du gaz', module: 'gas' },
  { id: 'view_gas', name: 'Voir gaz', description: 'Consulter le stock de gaz', module: 'gas' },
  { id: 'manage_expenses', name: 'Gérer dépenses', description: 'Ajouter et gérer les dépenses', module: 'expenses' },
  { id: 'view_expenses', name: 'Voir dépenses', description: 'Consulter les dépenses', module: 'expenses' },
  { id: 'manage_debts', name: 'Gérer créances', description: 'Gestion des créances', module: 'debts' },
  { id: 'view_reports', name: 'Voir rapports', description: 'Accès aux rapports', module: 'reports' },
  { id: 'manage_settings', name: 'Gérer paramètres', description: 'Modifier les paramètres système', module: 'settings' },
  { id: 'manage_users', name: 'Gérer utilisateurs', description: 'Gestion complète des utilisateurs', module: 'users' }
];

export function UserManagement() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useLocalStorage<User[]>('kitchen-store-users', []);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('users');
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    firstName: '',
    lastName: '',
    role: 'seller' as 'admin' | 'manager' | 'seller' | 'viewer',
    isActive: true,
    password: '',
    confirmPassword: '',
    permissions: [] as string[]
  });

  useEffect(() => {
    if (editingUser) {
      setFormData({
        username: editingUser.username,
        email: editingUser.email || '',
        firstName: editingUser.firstName,
        lastName: editingUser.lastName,
        role: editingUser.role === 'user' ? 'seller' : editingUser.role as 'admin' | 'manager' | 'seller' | 'viewer',
        isActive: editingUser.isActive,
        password: '',
        confirmPassword: '',
        permissions: editingUser.permissions || []
      });
    } else {
      setFormData({
        username: '',
        email: '',
        firstName: '',
        lastName: '',
        role: 'seller',
        isActive: true,
        password: '',
        confirmPassword: '',
        permissions: getDefaultPermissionsForRole('seller')
      });
    }
  }, [editingUser]);

  const getDefaultPermissionsForRole = (role: string): string[] => {
    switch (role) {
      case 'admin':
        return defaultPermissions.map(p => p.id);
      case 'manager':
        return defaultPermissions.filter(p => !p.id.includes('manage_users')).map(p => p.id);
      case 'seller':
        return defaultPermissions.filter(p => 
          p.id.includes('view_') || 
          p.id === 'manage_sales' || 
          p.id === 'manage_gas'
        ).map(p => p.id);
      case 'viewer':
        return defaultPermissions.filter(p => p.id.includes('view_')).map(p => p.id);
      default:
        return [];
    }
  };

  const handleRoleChange = (newRole: string) => {
    setFormData({
      ...formData, 
      role: newRole as any,
      permissions: getDefaultPermissionsForRole(newRole)
    });
  };

  const handlePermissionChange = (permissionId: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      permissions: checked 
        ? [...prev.permissions, permissionId]
        : prev.permissions.filter(id => id !== permissionId)
    }));
  };

  const validateForm = () => {
    if (!formData.username) {
      toast({
        title: "Erreur",
        description: "Le nom d'utilisateur est obligatoire",
        variant: "destructive"
      });
      return false;
    }

    // Vérifier si le nom d'utilisateur existe déjà
    const existingUser = users.find(u => u.username === formData.username && u.id !== editingUser?.id);
    if (existingUser) {
      toast({
        title: "Erreur",
        description: "Ce nom d'utilisateur existe déjà",
        variant: "destructive"
      });
      return false;
    }

    // Validation pour nouveaux utilisateurs
    if (!editingUser) {
      if (!formData.firstName || !formData.lastName) {
        toast({
          title: "Erreur",
          description: "Le prénom et le nom sont obligatoires",
          variant: "destructive"
        });
        return false;
      }

      if (!formData.password) {
        toast({
          title: "Erreur",
          description: "Le mot de passe est obligatoire pour un nouvel utilisateur",
          variant: "destructive"
        });
        return false;
      }

      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Erreur",
          description: "Les mots de passe ne correspondent pas",
          variant: "destructive"
        });
        return false;
      }

      if (formData.password.length < 4) {
        toast({
          title: "Erreur",
          description: "Le mot de passe doit contenir au moins 4 caractères",
          variant: "destructive"
        });
        return false;
      }
    }

    return true;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    if (editingUser) {
      // Modification d'un utilisateur existant
      const updatedUsers = users.map(u => 
        u.id === editingUser.id 
          ? { 
              ...u, 
              username: formData.username,
              role: formData.role,
              isActive: formData.isActive,
              permissions: formData.permissions,
              updatedAt: new Date()
            }
          : u
      );
      setUsers(updatedUsers);
      toast({
        title: "Utilisateur modifié",
        description: "Les informations ont été mises à jour avec succès",
      });
    } else {
      // Création d'un nouvel utilisateur
      const newUser: User = {
        id: Date.now().toString(),
        username: formData.username,
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        role: formData.role,
        isActive: formData.isActive,
        permissions: formData.permissions,
        createdAt: new Date(),
        // En production, hasher le mot de passe
        password: formData.password
      } as any;
      setUsers([...users, newUser]);
      toast({
        title: "Utilisateur créé",
        description: "Le nouvel utilisateur a été créé avec succès",
      });
    }

    setIsDialogOpen(false);
    setEditingUser(null);
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setIsDialogOpen(true);
  };

  const handleDelete = (userId: string) => {
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) return;

    // Empêcher la suppression de soi-même
    if (userId === currentUser?.id) {
      toast({
        title: "Impossible de supprimer",
        description: "Vous ne pouvez pas supprimer votre propre compte",
        variant: "destructive"
      });
      return;
    }

    // Empêcher la suppression du dernier admin
    const adminCount = users.filter(u => u.role === 'admin').length;
    if (userToDelete.role === 'admin' && adminCount === 1) {
      toast({
        title: "Impossible de supprimer",
        description: "Vous ne pouvez pas supprimer le dernier administrateur",
        variant: "destructive"
      });
      return;
    }

    setUsers(users.filter(u => u.id !== userId));
    toast({
      title: "Utilisateur supprimé",
      description: "L'utilisateur a été supprimé avec succès",
    });
  };

  const toggleUserStatus = (userId: string) => {
    // Empêcher la désactivation de soi-même
    if (userId === currentUser?.id) {
      toast({
        title: "Impossible de modifier",
        description: "Vous ne pouvez pas désactiver votre propre compte",
        variant: "destructive"
      });
      return;
    }

    const updatedUsers = users.map(u => 
      u.id === userId ? { ...u, isActive: !u.isActive } : u
    );
    setUsers(updatedUsers);
    
    const user = users.find(u => u.id === userId);
    toast({
      title: user?.isActive ? "Utilisateur désactivé" : "Utilisateur activé",
      description: `${user?.username} a été ${user?.isActive ? 'désactivé' : 'activé'}`,
    });
  };

  const getRoleLabel = (role: string) => {
    const labels = {
      admin: 'Administrateur',
      manager: 'Gestionnaire',
      seller: 'Vendeur',
      viewer: 'Observateur',
      user: 'Utilisateur' // Pour la compatibilité
    };
    return labels[role as keyof typeof labels] || role;
  };

  const getRoleColor = (role: string) => {
    const colors = {
      admin: 'bg-red-100 text-red-800',
      manager: 'bg-blue-100 text-blue-800',
      seller: 'bg-green-100 text-green-800',
      viewer: 'bg-gray-100 text-gray-800',
      user: 'bg-green-100 text-green-800' // Pour la compatibilité
    };
    return colors[role as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getRoleDescription = (role: string) => {
    const descriptions = {
      admin: 'Accès complet à toutes les fonctionnalités',
      manager: 'Gestion avancée sans administration des utilisateurs',
      seller: 'Accès aux ventes et consultation des stocks',
      viewer: 'Consultation uniquement, aucune modification'
    };
    return descriptions[role as keyof typeof descriptions] || '';
  };

  // Seuls les admins peuvent voir cette page
  if (currentUser?.role !== 'admin') {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Accès non autorisé</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestion des Utilisateurs</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => {
              setEditingUser(null);
              setIsDialogOpen(true);
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Nouvel Utilisateur
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingUser ? 'Modifier l\'utilisateur' : 'Créer un nouvel utilisateur'}
              </DialogTitle>
              <DialogDescription>
                {editingUser 
                  ? 'Modifiez les informations et permissions de l\'utilisateur'
                  : 'Créez un nouveau compte utilisateur avec les permissions appropriées'
                }
              </DialogDescription>
            </DialogHeader>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Informations de base</TabsTrigger>
                <TabsTrigger value="permissions">Rôles & Permissions</TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                {/* Champs prénom/nom uniquement pour la création */}
                {!editingUser && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Prénom *</Label>
                      <Input
                        value={formData.firstName}
                        onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                        placeholder="Prénom"
                      />
                    </div>
                    <div>
                      <Label>Nom *</Label>
                      <Input
                        value={formData.lastName}
                        onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                        placeholder="Nom"
                      />
                    </div>
                  </div>
                )}
                
                <div>
                  <Label>Nom d'utilisateur *</Label>
                  <Input
                    value={formData.username}
                    onChange={(e) => setFormData({...formData, username: e.target.value})}
                    placeholder="Nom d'utilisateur"
                  />
                </div>
                
                {/* Email uniquement pour la création */}
                {!editingUser && (
                  <div>
                    <Label>Email (optionnel)</Label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="Email"
                    />
                  </div>
                )}

                {/* Mots de passe uniquement pour la création */}
                {!editingUser && (
                  <>
                    <div>
                      <Label>Mot de passe *</Label>
                      <Input
                        type="password"
                        value={formData.password}
                        onChange={(e) => setFormData({...formData, password: e.target.value})}
                        placeholder="Mot de passe"
                      />
                    </div>
                    
                    <div>
                      <Label>Confirmer le mot de passe *</Label>
                      <Input
                        type="password"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                        placeholder="Confirmer le mot de passe"
                      />
                    </div>
                  </>
                )}
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isActive"
                    checked={formData.isActive}
                    onCheckedChange={(checked) => setFormData({...formData, isActive: checked as boolean})}
                  />
                  <Label htmlFor="isActive">Compte actif</Label>
                </div>
              </TabsContent>

              <TabsContent value="permissions" className="space-y-4">
                <div>
                  <Label>Rôle principal</Label>
                  <Select value={formData.role} onValueChange={handleRoleChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">
                        <div className="flex items-center space-x-2">
                          <Shield className="w-4 h-4" />
                          <div>
                            <div>Administrateur</div>
                            <div className="text-xs text-gray-500">Accès complet</div>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="manager">
                        <div className="flex items-center space-x-2">
                          <Settings className="w-4 h-4" />
                          <div>
                            <div>Gestionnaire</div>
                            <div className="text-xs text-gray-500">Gestion avancée</div>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="seller">
                        <div className="flex items-center space-x-2">
                          <UserCheck className="w-4 h-4" />
                          <div>
                            <div>Vendeur</div>
                            <div className="text-xs text-gray-500">Ventes et consultations</div>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="viewer">
                        <div className="flex items-center space-x-2">
                          <UserX className="w-4 h-4" />
                          <div>
                            <div>Observateur</div>
                            <div className="text-xs text-gray-500">Consultation uniquement</div>
                          </div>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-gray-500 mt-1">
                    {getRoleDescription(formData.role)}
                  </p>
                </div>

                <div>
                  <Label>Permissions détaillées</Label>
                  <div className="mt-2 space-y-3 max-h-60 overflow-y-auto border rounded p-3">
                    {Object.entries(
                      defaultPermissions.reduce((acc, permission) => {
                        if (!acc[permission.module]) acc[permission.module] = [];
                        acc[permission.module].push(permission);
                        return acc;
                      }, {} as Record<string, Permission[]>)
                    ).map(([module, permissions]) => (
                      <div key={module}>
                        <h4 className="font-medium text-sm mb-2 capitalize">{module}</h4>
                        <div className="space-y-2 ml-4">
                          {permissions.map((permission) => (
                            <div key={permission.id} className="flex items-center space-x-2">
                              <Checkbox
                                id={permission.id}
                                checked={formData.permissions.includes(permission.id)}
                                onCheckedChange={(checked) => 
                                  handlePermissionChange(permission.id, checked as boolean)
                                }
                              />
                              <Label htmlFor={permission.id} className="text-sm">
                                <div>{permission.name}</div>
                                <div className="text-xs text-gray-500">{permission.description}</div>
                              </Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setIsDialogOpen(false)}
              >
                Annuler
              </Button>
              <Button onClick={handleSubmit}>
                {editingUser ? 'Modifier' : 'Créer'} l'utilisateur
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Total utilisateurs</p>
              <p className="text-2xl font-bold">{users.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Actifs</p>
              <p className="text-2xl font-bold text-green-600">
                {users.filter(u => u.isActive).length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Administrateurs</p>
              <p className="text-2xl font-bold text-red-600">
                {users.filter(u => u.role === 'admin').length}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div>
              <p className="text-sm text-gray-600">Vendeurs</p>
              <p className="text-2xl font-bold text-blue-600">
                {users.filter(u => u.role === 'seller' || u.role === 'user').length}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Liste des utilisateurs */}
      <Card>
        <CardHeader>
          <CardTitle>Liste des utilisateurs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-sm font-medium">
                    {user.firstName[0]}{user.lastName[0]}
                  </div>
                  <div>
                    <h3 className="font-medium">{user.firstName} {user.lastName}</h3>
                    <p className="text-sm text-gray-500">@{user.username} {user.email && `• ${user.email}`}</p>
                    <p className="text-xs text-gray-400">
                      Créé le {new Date(user.createdAt).toLocaleDateString()}
                      {user.lastLogin && ` • Dernière connexion: ${new Date(user.lastLogin).toLocaleDateString()}`}
                    </p>
                    {user.permissions && user.permissions.length > 0 && (
                      <p className="text-xs text-blue-600 mt-1">
                        {user.permissions.length} permission(s) spécifique(s)
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getRoleColor(user.role)}>
                    {getRoleLabel(user.role)}
                  </Badge>
                  <Badge variant={user.isActive ? "default" : "secondary"}>
                    {user.isActive ? "Actif" : "Inactif"}
                  </Badge>
                  <div className="flex space-x-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(user)}
                      title="Modifier l'utilisateur"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleUserStatus(user.id)}
                      title={user.isActive ? "Désactiver" : "Activer"}
                    >
                      {user.isActive ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                    </Button>
                    {user.id !== currentUser?.id && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(user.id)}
                        className="text-red-600 hover:text-red-700"
                        title="Supprimer l'utilisateur"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {users.length === 0 && (
              <div className="text-center text-gray-500 py-8">
                Aucun utilisateur créé
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
