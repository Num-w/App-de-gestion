
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  isFirstTime: boolean;
  setupAdmin: (adminData: any) => Promise<boolean>;
  hasAdminAccount: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useLocalStorage('kitchen-store-users', []);
  const [currentUser, setCurrentUser] = useLocalStorage<User | null>('kitchen-store-current-user', null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isFirstTime, setIsFirstTime] = useState(false);
  const [hasAdminAccount, setHasAdminAccount] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setIsAuthenticated(true);
    }
    
    // Vérifier s'il existe un compte admin
    const adminExists = users.some((user: any) => user.role === 'admin');
    setHasAdminAccount(adminExists);
    setIsFirstTime(!adminExists);
  }, [currentUser, users]);

  const setupAdmin = async (adminData: any): Promise<boolean> => {
    try {
      const adminUser = {
        id: '1',
        username: adminData.username,
        password: adminData.password, // En production, utiliser bcrypt
        email: adminData.email,
        firstName: adminData.firstName,
        lastName: adminData.lastName,
        role: 'admin' as const,
        isActive: true,
        createdAt: new Date(),
        lastLogin: null,
        permissions: ['*'] // Toutes permissions
      };

      setUsers([adminUser]);
      const { password: _, ...userWithoutPassword } = adminUser;
      setCurrentUser(userWithoutPassword);
      setIsAuthenticated(true);
      setIsFirstTime(false);
      setHasAdminAccount(true);
      
      return true;
    } catch (error) {
      console.error('Erreur lors de la création du compte admin:', error);
      return false;
    }
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    const user = users.find((u: any) => u.username === username && u.password === password);
    
    if (user) {
      const { password: _, ...userWithoutPassword } = user;
      // Mettre à jour la dernière connexion
      const updatedUser = { ...user, lastLogin: new Date() };
      const updatedUsers = users.map((u: any) => u.id === user.id ? updatedUser : u);
      setUsers(updatedUsers);
      
      setCurrentUser(userWithoutPassword);
      setIsAuthenticated(true);
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{
      user: currentUser,
      login,
      logout,
      isAuthenticated,
      isFirstTime,
      setupAdmin,
      hasAdminAccount
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
