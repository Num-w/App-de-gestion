
import React, { createContext, useContext, ReactNode } from 'react';
import { Product, Sale, GasBottle, GasSale, Debt, StoreSettings, DashboardStats } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface StoreContextType {
  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'lastUpdated'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  
  // Sales
  sales: Sale[];
  addSale: (sale: Omit<Sale, 'id'>) => void;
  
  // Gas
  gasBottles: GasBottle[];
  addGasBottle: (bottle: Omit<GasBottle, 'id'>) => void;
  updateGasBottle: (id: string, bottle: Partial<GasBottle>) => void;
  
  gasSales: GasSale[];
  addGasSale: (sale: Omit<GasSale, 'id'>) => void;
  
  // Debts
  debts: Debt[];
  addDebt: (debt: Omit<Debt, 'id'>) => void;
  updateDebt: (id: string, debt: Partial<Debt>) => void;
  deleteDebt: (id: string) => void;
  
  // Settings
  settings: StoreSettings;
  updateSettings: (settings: Partial<StoreSettings>) => void;
  
  // Stats
  getDashboardStats: () => DashboardStats;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const DEFAULT_SETTINGS: StoreSettings = {
  name: 'Cuisine Hub',
  contact: '+237 6XX XXX XXX',
  address: 'Douala, Cameroun',
  currency: 'XAF',
  taxRate: 0
};

export function StoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useLocalStorage<Product[]>('kitchen-store-products', []);
  const [sales, setSales] = useLocalStorage<Sale[]>('kitchen-store-sales', []);
  const [gasBottles, setGasBottles] = useLocalStorage<GasBottle[]>('kitchen-store-gas-bottles', []);
  const [gasSales, setGasSales] = useLocalStorage<GasSale[]>('kitchen-store-gas-sales', []);
  const [debts, setDebts] = useLocalStorage<Debt[]>('kitchen-store-debts', []);
  const [settings, setSettings] = useLocalStorage<StoreSettings>('kitchen-store-settings', DEFAULT_SETTINGS);

  const generateId = () => Date.now().toString() + Math.random().toString(36).substr(2, 9);

  const addProduct = (product: Omit<Product, 'id' | 'lastUpdated'>) => {
    const newProduct: Product = {
      ...product,
      id: generateId(),
      lastUpdated: new Date()
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, productUpdate: Partial<Product>) => {
    setProducts(prev => prev.map(p => 
      p.id === id ? { ...p, ...productUpdate, lastUpdated: new Date() } : p
    ));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addSale = (sale: Omit<Sale, 'id'>) => {
    const newSale: Sale = {
      ...sale,
      id: generateId()
    };
    setSales(prev => [...prev, newSale]);
    
    // Mettre à jour le stock
    sale.products.forEach(item => {
      updateProduct(item.productId, {
        quantity: products.find(p => p.id === item.productId)!.quantity - item.quantity
      });
    });
  };

  const addGasBottle = (bottle: Omit<GasBottle, 'id'>) => {
    const newBottle: GasBottle = {
      ...bottle,
      id: generateId()
    };
    setGasBottles(prev => [...prev, newBottle]);
  };

  const updateGasBottle = (id: string, bottleUpdate: Partial<GasBottle>) => {
    setGasBottles(prev => prev.map(b => 
      b.id === id ? { ...b, ...bottleUpdate } : b
    ));
  };

  const addGasSale = (sale: Omit<GasSale, 'id'>) => {
    const newSale: GasSale = {
      ...sale,
      id: generateId()
    };
    setGasSales(prev => [...prev, newSale]);
    
    // Mettre à jour le stock de gaz
    const bottle = gasBottles.find(b => b.id === sale.bottleId);
    if (bottle) {
      updateGasBottle(sale.bottleId, {
        quantity: bottle.quantity - sale.quantity
      });
    }
  };

  const addDebt = (debt: Omit<Debt, 'id'>) => {
    const newDebt: Debt = {
      ...debt,
      id: generateId(),
      payments: []
    };
    setDebts(prev => [...prev, newDebt]);
  };

  const updateDebt = (id: string, debtUpdate: Partial<Debt>) => {
    setDebts(prev => prev.map(d => 
      d.id === id ? { ...d, ...debtUpdate } : d
    ));
  };

  const deleteDebt = (id: string) => {
    setDebts(prev => prev.filter(d => d.id !== id));
  };

  const updateSettings = (settingsUpdate: Partial<StoreSettings>) => {
    setSettings(prev => ({ ...prev, ...settingsUpdate }));
  };

  const getDashboardStats = (): DashboardStats => {
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const startOfWeek = new Date(today.getTime() - (today.getDay() * 24 * 60 * 60 * 1000));
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    const todaysSales = sales
      .filter(sale => new Date(sale.date) >= startOfDay)
      .reduce((sum, sale) => sum + sale.total, 0);

    const weekSales = sales
      .filter(sale => new Date(sale.date) >= startOfWeek)
      .reduce((sum, sale) => sum + sale.total, 0);

    const monthSales = sales
      .filter(sale => new Date(sale.date) >= startOfMonth)
      .reduce((sum, sale) => sum + sale.total, 0);

    const lowStockProducts = products.filter(p => p.quantity <= p.minStock).length;
    const totalDebts = debts.filter(d => d.type === 'customer' && d.status === 'pending')
      .reduce((sum, d) => sum + d.amount, 0);
    const totalCredits = debts.filter(d => d.type === 'supplier' && d.status === 'pending')
      .reduce((sum, d) => sum + d.amount, 0);

    return {
      todaysSales,
      weekSales,
      monthSales,
      totalProducts: products.length,
      lowStockProducts,
      totalDebts,
      totalCredits
    };
  };

  return (
    <StoreContext.Provider value={{
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      sales,
      addSale,
      gasBottles,
      addGasBottle,
      updateGasBottle,
      gasSales,
      addGasSale,
      debts,
      addDebt,
      updateDebt,
      deleteDebt,
      settings,
      updateSettings,
      getDashboardStats
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
