
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { ThemeConfig } from '../types';

type ThemeMode = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: ThemeMode;
  blueTheme: string | null;
  setTheme: (theme: ThemeMode) => void;
  setBlueTheme: (theme: string | null) => void;
  systemTheme: ThemeMode;
}

const blueThemes: {[key: string]: ThemeConfig} = {
  "Bleu Classique": {
    name: "Bleu Classique",
    primary: "#2563eb",
    secondary: "#3b82f6", 
    accent: "#1d4ed8",
    background: "#f8fafc",
    text: "#1e293b"
  },
  "Bleu Nuit": {
    name: "Bleu Nuit",
    primary: "#1e40af",
    secondary: "#2563eb",
    accent: "#60a5fa", 
    background: "#0f172a",
    text: "#f1f5f9"
  }
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useLocalStorage<ThemeMode>('app-theme', 'light');
  const [blueTheme, setBlueThemeState] = useLocalStorage<string | null>('blue-theme', null);
  const [systemTheme, setSystemTheme] = useState<ThemeMode>('light');

  // Detect system preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const updateSystemTheme = () => {
      setSystemTheme(mediaQuery.matches ? 'dark' : 'light');
    };
    
    updateSystemTheme();
    mediaQuery.addEventListener('change', updateSystemTheme);
    
    return () => mediaQuery.removeEventListener('change', updateSystemTheme);
  }, []);

  // Apply theme to document
  useEffect(() => {
    const root = document.documentElement;
    
    // Apply light/dark theme
    const currentTheme = theme === 'system' ? systemTheme : theme;
    root.classList.toggle('dark', currentTheme === 'dark');
    
    // Remove any existing blue theme classes
    Object.keys(blueThemes).forEach(themeName => {
      const className = `theme-${themeName.toLowerCase().replace(/ /g, '-')}`;
      root.classList.remove(className);
    });
    
    // Apply blue theme if selected
    if (blueTheme && blueThemes[blueTheme]) {
      const themeClass = `theme-${blueTheme.toLowerCase().replace(/ /g, '-')}`;
      root.classList.add(themeClass);
      
      // Apply CSS custom properties for the blue theme
      const config = blueThemes[blueTheme];
      root.style.setProperty('--theme-primary', config.primary);
      root.style.setProperty('--theme-secondary', config.secondary);
      root.style.setProperty('--theme-accent', config.accent);
      root.style.setProperty('--theme-background', config.background);
      root.style.setProperty('--theme-text', config.text);
    } else {
      // Remove custom properties if no blue theme
      root.style.removeProperty('--theme-primary');
      root.style.removeProperty('--theme-secondary');
      root.style.removeProperty('--theme-accent');
      root.style.removeProperty('--theme-background');
      root.style.removeProperty('--theme-text');
    }
  }, [theme, blueTheme, systemTheme]);

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
  };

  const setBlueTheme = (newBlueTheme: string | null) => {
    setBlueThemeState(newBlueTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, blueTheme, setTheme, setBlueTheme, systemTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}

export function getAllBlueThemes() {
  return Object.values(blueThemes);
}
