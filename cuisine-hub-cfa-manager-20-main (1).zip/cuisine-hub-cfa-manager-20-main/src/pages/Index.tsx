
import React, { useState } from 'react';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { AppSidebar } from '../components/AppSidebar';
import { LoginForm } from '../components/LoginForm';
import { FirstTimeSetup } from '../components/FirstTimeSetup';
import { Dashboard } from '../components/Dashboard';
import { ProductsManagement } from '../components/ProductsManagement';
import { SalesManagement } from '../components/SalesManagement';
import { GasManagement } from '../components/GasManagement';
import { ExpenseManagement } from '../components/ExpenseManagement';
import { DebtsManagement } from '../components/DebtsManagement';
import { MarginManagement } from '../components/MarginManagement';
import { ReportsManagement } from '../components/ReportsManagement';
import { MemosManagement } from '../components/MemosManagement';
import { SettingsManagement } from '../components/SettingsManagement';
import { UserManagement } from '../components/UserManagement';
import { AuthProvider, useAuth } from '../contexts/AuthContext';
import { StoreProvider } from '../contexts/StoreContext';
import { Toaster } from '@/components/ui/toaster';

function MainApp() {
  const { isAuthenticated, isFirstTime, user } = useAuth();
  const [activeSection, setActiveSection] = useState('dashboard');

  // Afficher la configuration initiale si c'est la première fois
  if (isFirstTime) {
    return <FirstTimeSetup />;
  }

  // Afficher la page de connexion si non authentifié
  if (!isAuthenticated) {
    return <LoginForm />;
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'products':
        return <ProductsManagement />;
      case 'sales':
        return <SalesManagement />;
      case 'gas':
        return <GasManagement />;
      case 'expenses':
        return <ExpenseManagement />;
      case 'debts':
        return <DebtsManagement />;
      case 'margins':
        return user?.role === 'admin' ? <MarginManagement /> : <Dashboard />;
      case 'reports':
        return <ReportsManagement />;
      case 'memos':
        return <MemosManagement />;
      case 'users':
        // Seuls les admins peuvent accéder à la gestion des utilisateurs
        return user?.role === 'admin' ? <UserManagement /> : <Dashboard />;
      case 'settings':
        return <SettingsManagement />;
      default:
        return <Dashboard />;
    }
  };

  const getSectionTitle = () => {
    const titles = {
      dashboard: 'Tableau de bord',
      products: 'Gestion des produits',
      sales: 'Gestion des ventes',
      gas: 'Gestion du gaz',
      expenses: 'Gestion des dépenses',
      debts: 'Gestion des créances',
      margins: 'Marge Bénéficiaire',
      reports: 'Rapports',
      memos: 'Mémos',
      users: 'Gestion des utilisateurs',
      settings: 'Paramètres'
    };
    return titles[activeSection as keyof typeof titles] || 'Tableau de bord';
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <AppSidebar 
          activeSection={activeSection} 
          onSectionChange={setActiveSection} 
        />
        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <SidebarTrigger />
                <div className="h-6 w-px bg-gray-300" />
                <h1 className="text-lg font-semibold text-gray-900">
                  {getSectionTitle()}
                </h1>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">
                  Connecté en tant que <strong>{user?.firstName} {user?.lastName}</strong>
                </span>
                <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-sm">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </div>
              </div>
            </div>
          </header>
          <div className="flex-1 overflow-auto p-6">
            {renderContent()}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

const Index = () => {
  return (
    <AuthProvider>
      <StoreProvider>
        <MainApp />
        <Toaster />
      </StoreProvider>
    </AuthProvider>
  );
};

export default Index;
