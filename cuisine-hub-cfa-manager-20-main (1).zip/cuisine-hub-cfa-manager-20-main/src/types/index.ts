
export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'user' | 'manager' | 'viewer' | 'seller';
  isActive: boolean;
  forcePasswordChange?: boolean;
  lastLogin?: Date;
  accountExpiry?: Date;
  createdAt: Date;
  updatedAt?: Date;
  avatar?: string;
  permissions?: string[];
  password?: string; // Pour le stockage local temporaire
}

export interface Product {
  id: string;
  name: string;
  category: string;
  quantity: number;
  purchasePrice: number;
  salePrice: number;
  supplier: string;
  entryDate: Date;
  lastUpdated: Date;
  minStock: number;
}

export interface Sale {
  id: string;
  products: SaleItem[];
  customerName: string;
  customerContact: string;
  total: number;
  date: Date;
  paymentMethod: 'cash' | 'credit';
}

export interface SaleItem {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export interface GasBottle {
  id: string;
  type: string;
  size: string;
  quantity: number;
  units: number;
  purchasePrice: number;
  salePrice: number;
  supplier: string;
  deliveryDate: Date;
  isExchange?: boolean;
  exchangePrice?: number;
}

export interface GasSale {
  id: string;
  bottleId?: string;
  bottleType: string;
  quantity: number;
  unitPrice: number;
  total: number;
  customerName: string;
  customerContact: string;
  date: Date;
  paymentMethod: 'cash' | 'credit';
  isExchange?: boolean;
}

export interface Debt {
  id: string;
  type: 'customer' | 'supplier';
  name: string;
  phone?: string;
  amount: number;
  createdDate: Date;
  dueDate: Date;
  status: 'pending' | 'paid' | 'partial';
  description: string;
  payments: Payment[];
}

export interface Payment {
  id: string;
  amount: number;
  date: Date;
  method: 'cash' | 'transfer' | 'check';
}

export interface StoreSettings {
  name: string;
  contact: string;
  address: string;
  currency: string;
  taxRate: number;
  logo?: string;
}

export interface DashboardStats {
  todaysSales: number;
  weekSales: number;
  monthSales: number;
  totalProducts: number;
  lowStockProducts: number;
  totalDebts: number;
  totalCredits: number;
}

export interface Memo {
  id: string;
  title: string;
  content: string;
  priority: 'low' | 'medium' | 'high';
  category: 'general' | 'stock' | 'vente' | 'rappel';
  createdAt: Date;
  completed: boolean;
  userId: string;
}

export interface ThemeConfig {
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
}

export interface Expense {
  id: string;
  type: 'operational' | 'supplier' | 'delivery' | 'maintenance' | 'other';
  amount: number;
  description: string;
  date: Date;
  supplier?: string;
  category: string;
  paymentMethod: 'cash' | 'transfer' | 'check';
  createdBy: string;
  createdAt: Date;
}

export interface Supplier {
  id: string;
  name: string;
  contact: string;
  email?: string;
  address?: string;
  category: string;
  createdAt: Date;
}

export interface Delivery {
  id: string;
  supplierId: string;
  supplierName: string;
  items: string[];
  totalAmount: number;
  deliveryDate: Date;
  status: 'pending' | 'delivered' | 'cancelled';
  notes?: string;
  createdBy: string;
  createdAt: Date;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  module: string;
}
